/* ══════════════════════════════════════════
   ANEXOS
══════════════════════════════════════════ */
function renderAnexos(){
  const search=(document.getElementById('anexo-search')?.value||'').toLowerCase();
  let items=ANEXOS;
  if(search)items=items.filter(a=>a.nome.toLowerCase().includes(search)||a.numero.toLowerCase().includes(search)||a.popVinculado.toLowerCase().includes(search));
  const body=document.getElementById('anexos-body');
  if(!body)return;
  body.innerHTML=items.map(a=>{
    const statusBadge=a.status==='Aprovado'?'<span class="badge badge-green">✓ Aprovado</span>':a.status==='Em Revisão'?'<span class="badge badge-orange">Em Revisão</span>':'<span class="badge badge-gray">Obsoleto</span>';
    const fi=a.file?fileIcon(a.file.type):fileIcon(null);
    const fileCell=a.file
      ?`<div style="display:flex;align-items:center;gap:7px"><div class="file-icon ${fi.cls}">${fi.icon}</div><div style="font-size:.7rem;color:var(--gray-soft);max-width:80px;word-break:break-all">${a.file.name.substring(0,18)}${a.file.name.length>18?'…':''}<br>${formatBytes(a.file.size)}</div></div>`
      :'<span style="color:var(--gray-soft);font-size:.75rem">—</span>';
    return`<tr>
      <td>${fileCell}</td>
      <td><strong style="color:var(--red)">${a.nome}</strong></td>
      <td style="font-weight:700">${a.numero}</td>
      <td><span class="badge badge-blue">${a.popVinculado}</span></td>
      <td style="max-width:200px;font-size:var(--fs-sm);color:var(--gray-soft)">${a.desc}</td>
      <td>${statusBadge}</td>
      <td style="font-size:var(--fs-xs);color:var(--gray-soft)">${a.dataCriacao}</td>
      <td style="font-size:var(--fs-xs);color:var(--gray-soft)">${a.dataRevisao}</td>
      <td style="font-size:var(--fs-xs);font-weight:700;color:${a.dataVencimento?'var(--green)':'var(--gray-soft)'}">${a.dataVencimento||'—'}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-outline btn-sm" onclick="openEditAnexo(${a.id})" style="margin-right:4px">Editar</button>
        <button class="btn btn-danger btn-sm" onclick="deleteAnexo(${a.id})">Excluir</button>
      </td>
    </tr>`;
  }).join('');
  if(!items.length)body.innerHTML=`<tr><td colspan="9" style="text-align:center;padding:24px;color:var(--gray-soft)">Nenhum anexo encontrado${search?' para "'+search+'"':''}.</td></tr>`;
}

function deleteAnexo(id){
  const a=ANEXOS.find(x=>x.id===id);
  if(!a)return;
  showConfirm('Excluir Anexo',`Tem certeza que deseja excluir o anexo "${a.nome}"?`,()=>{
    addLog(`Anexo Excluído: ${a.numero}`, 'delete', `${a.nome} · POP: ${a.popVinculado}`);
    ANEXOS=ANEXOS.filter(x=>x.id!==id);
    saveData();
    toast('Anexo Excluído', `${a.nome} removido.`, 'warn');
    renderAnexos();
  });
}

function openEditAnexo(id){
  const a=ANEXOS.find(x=>x.id===id);
  if(!a)return;
  // Convert stored date (dd/mm/yyyy) to input format (yyyy-mm-dd)
  const toInputDate = str => {
    if(!str||str==='—') return '';
    const p=str.split('/'); if(p.length!==3) return '';
    return `${p[2]}-${p[1].padStart(2,'0')}-${p[0].padStart(2,'0')}`;
  };
  const dataRevisaoInput = toInputDate(a.dataRevisao) || new Date().toISOString().slice(0,10);
  openModal(`Editar Anexo — <span>${a.numero}</span>`,`
    <div class="form-grid">
      <div class="form-group"><label class="form-label">Nome</label><input type="text" class="form-input" id="ea-nome" value="${a.nome}"></div>
      <div class="form-group"><label class="form-label">Número</label><input type="text" class="form-input" id="ea-numero" value="${a.numero}"></div>
      <div class="form-group"><label class="form-label">POP Vinculado</label>
        <select class="form-select" id="ea-pop">
          ${POPS.map(p=>`<option value="${p.code}" ${p.code===a.popVinculado?'selected':''}>${p.code}</option>`).join('')}
        </select>
      </div>
      <div class="form-group"><label class="form-label">Status</label>
        <select class="form-select" id="ea-status">
          <option value="Aprovado" ${a.status==='Aprovado'?'selected':''}>Aprovado</option>
          <option value="Em Revisão" ${a.status==='Em Revisão'?'selected':''}>Em Revisão</option>
          <option value="Obsoleto" ${a.status==='Obsoleto'?'selected':''}>Obsoleto</option>
        </select>
      </div>
    </div>
    <div class="form-group"><label class="form-label">Descrição</label><textarea class="form-input" id="ea-desc" rows="3">${a.desc}</textarea></div>
    <div class="form-grid" style="margin-bottom:8px">
      <div class="form-group">
        <label class="form-label">Data de Revisão</label>
        <input type="date" class="form-input" id="ea-data-revisao" value="${dataRevisaoInput}" oninput="atualizarVencimentoEditAnexo()">
      </div>
      <div class="form-group">
        <label class="form-label">Vencimento (5 anos)</label>
        <input type="text" class="form-input" id="ea-vencimento" readonly style="background:var(--gray-pale);cursor:not-allowed;font-weight:700;color:var(--green)">
      </div>
    </div>
    <div id="ea-venc-preview" style="padding:10px 14px;background:var(--green-bg);border-radius:var(--r);border-left:3px solid var(--green);font-size:var(--fs-sm);margin-bottom:14px">
      Vencimento: <strong id="ea-venc-label" style="color:var(--green)"></strong> · <span id="ea-dias-label" style="font-weight:700"></span>
    </div>
    <div style="display:flex;gap:10px;margin-top:8px;flex-wrap:wrap">
      <button class="btn btn-primary" onclick="salvarEditAnexo(${id})">Salvar</button>
      <button class="btn btn-danger" onclick="closeModal();deleteAnexo(${id})">Excluir</button>
      <button class="btn btn-outline" onclick="closeModal()">Cancelar</button>
    </div>
  `);
  atualizarVencimentoEditAnexo();
}

function atualizarVencimentoEditAnexo(){
  const raw = document.getElementById('ea-data-revisao')?.value;
  const vencEl = document.getElementById('ea-vencimento');
  const labelEl = document.getElementById('ea-venc-label');
  const diasEl = document.getElementById('ea-dias-label');
  if(!raw || !vencEl) return;
  const d = new Date(raw+'T00:00:00');
  const venc = new Date(d); venc.setFullYear(venc.getFullYear()+5);
  const vencStr = venc.toLocaleDateString('pt-BR');
  vencEl.value = vencStr;
  if(labelEl) labelEl.textContent = vencStr;
  const dias = Math.ceil((venc - new Date()) / 86400000);
  if(diasEl){
    if(dias<0){ diasEl.textContent=`Vencido há ${Math.abs(dias)} dias`; diasEl.style.color='var(--red)'; }
    else if(dias<=90){ diasEl.textContent=`${dias} dias restantes`; diasEl.style.color='var(--orange)'; }
    else { diasEl.textContent=`${dias} dias restantes`; diasEl.style.color='var(--green)'; }
  }
}

function salvarEditAnexo(id){
  const a=ANEXOS.find(x=>x.id===id);
  if(!a)return;
  a.nome=document.getElementById('ea-nome').value.trim()||a.nome;
  a.numero=document.getElementById('ea-numero').value.trim()||a.numero;
  a.popVinculado=document.getElementById('ea-pop').value||a.popVinculado;
  a.status=document.getElementById('ea-status').value;
  a.desc=document.getElementById('ea-desc').value.trim()||a.desc;
  const rawDate = document.getElementById('ea-data-revisao')?.value;
  if(rawDate){
    const d = new Date(rawDate+'T00:00:00');
    a.dataRevisao = d.toLocaleDateString('pt-BR');
    const venc = new Date(d); venc.setFullYear(venc.getFullYear()+5);
    a.dataVencimento = venc.toLocaleDateString('pt-BR');
  }
  addLog(`Anexo Editado: ${a.numero}`, 'edit', `${a.nome} · Status: ${a.status}${a.dataVencimento?' · Venc: '+a.dataVencimento:''}`);
  saveData();
  toast('Anexo Atualizado', `${a.nome} salvo.`, 'success');
  closeModal();renderAnexos();
}

function openCriarAnexo(){
  const hoje = new Date().toISOString().slice(0,10);
  openModal('+ Criar <span>Anexo</span>',`
    <div class="form-grid">
      <div class="form-group"><label class="form-label">Nome do Anexo</label><input type="text" class="form-input" id="anx-nome" placeholder="Ex: Ficha de Calibração..."></div>
      <div class="form-group"><label class="form-label">Número (Romano)</label><input type="text" class="form-input" id="anx-numero" placeholder="Ex: I, II, III..."></div>
      <div class="form-group"><label class="form-label">POP Vinculado</label>
        <select class="form-select" id="anx-pop">
          <option value="">— Selecione —</option>
          ${POPS.map(p=>`<option value="${p.code}">${p.code} — ${p.desc.substring(0,38)}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Data de Criação</label>
        <input type="date" class="form-input" id="anx-data" value="${hoje}" oninput="atualizarVencimentoAnexo()">
      </div>
    </div>
    <div style="padding:10px 14px;background:var(--green-bg);border-radius:var(--r);border-left:3px solid var(--green);font-size:var(--fs-sm);margin-bottom:14px">
      ⏳ Vencimento automático (5 anos): <strong id="anx-venc-label" style="color:var(--green)"></strong> · <span id="anx-dias-label" style="font-weight:700"></span>
    </div>
    <div class="form-group"><label class="form-label">Arquivo (opcional)</label>
      <input type="file" class="form-input" id="anx-file" accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg" style="padding:8px">
    </div>
    <div class="form-group"><label class="form-label">Descrição</label><textarea class="form-input" id="anx-desc" rows="3" placeholder="Descreva o conteúdo e finalidade do anexo..."></textarea></div>
    <button class="btn btn-primary" onclick="salvarCriarAnexo()">✓ Criar Anexo</button>
  `);
  atualizarVencimentoAnexo();
}

function atualizarVencimentoAnexo(){
  const raw = document.getElementById('anx-data')?.value;
  const labelEl = document.getElementById('anx-venc-label');
  const diasEl = document.getElementById('anx-dias-label');
  if(!raw) return;
  const d = new Date(raw+'T00:00:00');
  const venc = new Date(d); venc.setFullYear(venc.getFullYear()+5);
  const vencStr = venc.toLocaleDateString('pt-BR');
  if(labelEl) labelEl.textContent = vencStr;
  const dias = Math.ceil((venc - new Date()) / 86400000);
  if(diasEl){
    if(dias < 0){ diasEl.textContent=`Vencido há ${Math.abs(dias)} dias`; diasEl.style.color='var(--red)'; }
    else if(dias<=90){ diasEl.textContent=`⚠ ${dias} dias restantes`; diasEl.style.color='var(--orange)'; }
    else { diasEl.textContent=`✓ ${dias} dias restantes`; diasEl.style.color='var(--green)'; }
  }
}

function salvarCriarAnexo(){
  const nome=document.getElementById('anx-nome').value.trim();
  const numero=document.getElementById('anx-numero').value.trim();
  const pop=document.getElementById('anx-pop').value;
  const desc=document.getElementById('anx-desc').value.trim();
  const dataRaw=document.getElementById('anx-data').value;
  const fileEl=document.getElementById('anx-file');
  if(!nome||!numero){toast('Campos obrigatórios','Preencha nome e número.','error');return;}
  let dataCriacao, dataVencimento;
  if(dataRaw){
    const d = new Date(dataRaw+'T00:00:00');
    dataCriacao = d.toLocaleDateString('pt-BR');
    const venc = new Date(d); venc.setFullYear(venc.getFullYear()+5);
    dataVencimento = venc.toLocaleDateString('pt-BR');
  } else {
    dataCriacao = new Date().toLocaleDateString('pt-BR');
    const venc = new Date(); venc.setFullYear(venc.getFullYear()+5);
    dataVencimento = venc.toLocaleDateString('pt-BR');
  }
  let fileData=null;
  if(fileEl&&fileEl.files&&fileEl.files[0]){
    const f=fileEl.files[0];
    fileData={name:f.name,size:f.size,type:f.type};
  }
  ANEXOS.push({id:nextAnexoId++,nome,numero,popVinculado:pop||'—',desc:desc||'Sem descrição.',status:'Em Revisão',dataCriacao,dataVencimento,dataRevisao:'—',file:fileData});
  addLog(`Anexo Criado: ${numero}`, 'create', `${nome} · POP: ${pop||'—'} · Venc: ${dataVencimento}`);
  saveData();
  toast('Anexo Criado', `${nome} — Vencimento: ${dataVencimento}.`, 'success');
  closeModal();renderAnexos();
}

function openRevisarAnexo(){
  const overlay=document.getElementById('revisar-anexo-overlay');
  const sel=document.getElementById('rev-anexo-select');
  sel.innerHTML='<option value="">— Selecione um anexo —</option>'+ANEXOS.map(a=>`<option value="${a.id}">${a.numero} — ${a.nome}</option>`).join('');
  document.getElementById('rev-anexo-preview').style.display='none';
  overlay.style.display='flex';
}
function fecharRevisarAnexo(){document.getElementById('revisar-anexo-overlay').style.display='none';}


function previewAnexoRevisao(){
  const id=parseInt(document.getElementById('rev-anexo-select').value);
  const preview=document.getElementById('rev-anexo-preview');
  if(!id){preview.style.display='none';return;}
  const a=ANEXOS.find(x=>x.id===id);
  if(!a)return;
  document.getElementById('rev-anexo-desc').value=a.desc;
  document.getElementById('rev-anexo-status').value=a.status;
  // Pre-fill date with today
  const hoje = new Date().toISOString().slice(0,10);
  document.getElementById('rev-anexo-data').value=hoje;
  document.getElementById('rev-anexo-datas').innerHTML=`Criado: <strong>${a.dataCriacao}</strong> · Última revisão: <strong>${a.dataRevisao}</strong>`;
  preview.style.display='block';
  atualizarVencimentoRevisaoAnexo();
}

function atualizarVencimentoRevisaoAnexo(){
  const raw = document.getElementById('rev-anexo-data')?.value;
  const vencEl = document.getElementById('rev-anexo-vencimento');
  const labelEl = document.getElementById('rev-anexo-venc-label');
  const diasEl = document.getElementById('rev-anexo-dias-label');
  const previewEl = document.getElementById('rev-anexo-venc-preview');
  if(!raw || !vencEl) return;
  const d = new Date(raw+'T00:00:00');
  const venc = new Date(d); venc.setFullYear(venc.getFullYear()+5);
  const vencStr = venc.toLocaleDateString('pt-BR');
  vencEl.value = vencStr;
  if(labelEl) labelEl.textContent = vencStr;
  const dias = Math.ceil((venc - new Date()) / 86400000);
  if(diasEl){
    if(dias<0){ diasEl.textContent=`Vencido há ${Math.abs(dias)} dias`; diasEl.style.color='var(--red)'; }
    else if(dias<=90){ diasEl.textContent=`${dias} dias restantes`; diasEl.style.color='var(--orange)'; }
    else { diasEl.textContent=`${dias} dias restantes`; diasEl.style.color='var(--green)'; }
  }
  if(previewEl) previewEl.style.display='';
}
function salvarRevisaoAnexo(){
  const id=parseInt(document.getElementById('rev-anexo-select').value);
  if(!id){toast('Selecione um anexo','Escolha um anexo para revisar.','warn');return;}
  const a=ANEXOS.find(x=>x.id===id);
  if(!a)return;
  a.desc=document.getElementById('rev-anexo-desc').value.trim();
  a.status=document.getElementById('rev-anexo-status').value;
  const rawDate = document.getElementById('rev-anexo-data')?.value;
  if(rawDate){
    const d = new Date(rawDate+'T00:00:00');
    a.dataRevisao = d.toLocaleDateString('pt-BR');
    const venc = new Date(d); venc.setFullYear(venc.getFullYear()+5);
    a.dataVencimento = venc.toLocaleDateString('pt-BR');
  } else {
    a.dataRevisao = new Date().toLocaleDateString('pt-BR');
    const venc = new Date(); venc.setFullYear(venc.getFullYear()+5);
    a.dataVencimento = venc.toLocaleDateString('pt-BR');
  }
  addLog(`Anexo Revisado: ${a.numero}`, 'edit', `${a.nome} · Novo status: ${a.status} · Venc: ${a.dataVencimento}`);
  saveData();
  toast('Revisão Salva', `${a.nome} revisado. Vencimento: ${a.dataVencimento}.`, 'success');
  fecharRevisarAnexo();renderAnexos();
}