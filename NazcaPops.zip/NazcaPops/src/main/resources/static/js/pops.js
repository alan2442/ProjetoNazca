function openRevisao(code){
  const pop=POPS.find(p=>p.code===code);
  if(!pop)return;
  const affected=TRAINING_MATRIX.filter(r=>r.pops.includes(code));
  const hoje = new Date().toISOString().slice(0,10);
  openModal(`Revisão — <span>${code}</span>`,`
    <div style="padding:12px 14px;background:var(--orange-bg);border-radius:var(--r);margin-bottom:14px;border-left:3px solid var(--orange)">
      <strong>${pop.desc}</strong>
      <div style="font-size:var(--fs-xs);color:var(--gray-soft);margin-top:4px">${pop.sectorName} · Status: ${pop.docStatus}</div>
      ${pop.dataVencimento?`<div style="font-size:var(--fs-xs);margin-top:4px">📅 Vencimento atual: <strong>${pop.dataVencimento}</strong></div>`:''}
    </div>
    <div style="font-weight:700;font-size:var(--fs-sm);margin-bottom:10px">Houve mudança na descrição do procedimento?</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <button class="btn btn-primary btn-sm" onclick="mostrarCaixaRevisao('${code}', true)">Sim — Mudou o Procedimento</button>
      <button class="btn btn-outline btn-sm" onclick="mostrarCaixaRenovarData('${code}')">Não — Apenas Renovar Data</button>
    </div>
    <div id="revisao-caixa-extra" style="margin-top:16px;display:none">
      <div class="form-group"><label class="form-label">Descreva as mudanças realizadas:</label><textarea class="form-input" id="revisao-mudancas" rows="4" placeholder="Descreva detalhadamente as alterações feitas no procedimento..."></textarea></div>
      <div class="form-grid" style="margin-bottom:10px">
        <div class="form-group">
          <label class="form-label">Data de Início da Revisão</label>
          <input type="date" class="form-input" id="revisao-data-inicio" value="${hoje}" oninput="atualizarVencimentoRevisao('revisao')">
        </div>
        <div class="form-group">
          <label class="form-label">Novo Vencimento (5 anos)</label>
          <input type="text" class="form-input" id="revisao-vencimento" readonly style="background:var(--gray-pale);cursor:not-allowed;font-weight:700;color:var(--green)">
        </div>
      </div>
      <button class="btn btn-primary" onclick="confirmarRevisao('${code}', true)">Confirmar e Revalidar</button>
    </div>
    <div id="renovar-caixa" style="margin-top:16px;display:none">
      <div style="padding:10px 14px;background:var(--blue-bg);border-radius:var(--r);border-left:3px solid var(--blue);font-size:var(--fs-sm);margin-bottom:12px">
        Informe a data de início desta renovação. O novo vencimento será calculado automaticamente em <strong>5 anos</strong>.
      </div>
      <div class="form-grid" style="margin-bottom:10px">
        <div class="form-group">
          <label class="form-label">Data de Início da Renovação</label>
          <input type="date" class="form-input" id="renovar-data-inicio" value="${hoje}" oninput="atualizarVencimentoRevisao('renovar')">
        </div>
        <div class="form-group">
          <label class="form-label">Novo Vencimento (5 anos)</label>
          <input type="text" class="form-input" id="renovar-vencimento" readonly style="background:var(--gray-pale);cursor:not-allowed;font-weight:700;color:var(--green)">
        </div>
      </div>
      <div id="renovar-preview" style="padding:10px 14px;background:var(--green-bg);border-radius:var(--r);border-left:3px solid var(--green);font-size:var(--fs-sm);margin-bottom:12px">
        ✅ Vencimento renovado para: <strong id="renovar-venc-label" style="color:var(--green)"></strong> · <span id="renovar-dias-label" style="font-weight:700"></span>
      </div>
      <button class="btn btn-primary" onclick="confirmarRevisao('${code}', false)">Confirmar Renovação</button>
    </div>
    <div style="margin-top:14px">
      <div style="font-weight:700;font-size:var(--fs-sm);margin-bottom:8px">${affected.length} cargo(s) afetado(s):</div>
      ${affected.map(r=>`<div style="display:flex;align-items:center;justify-content:space-between;padding:7px 12px;border-radius:8px;background:var(--gray-pale);margin-bottom:5px;font-size:var(--fs-sm)"><span><strong>${r.role}</strong></span><span class="badge badge-blue">${r.sector}</span></div>`).join('')||'<div style="color:var(--gray-soft);font-size:var(--fs-sm)">Nenhum cargo mapeado.</div>'}
    </div>
  `);
  // Pre-fill vencimento fields
  atualizarVencimentoRevisao('revisao');
  atualizarVencimentoRevisao('renovar');
}

function mostrarCaixaRevisao(code, changed){
  document.getElementById('revisao-caixa-extra').style.display='block';
  document.getElementById('renovar-caixa').style.display='none';
  atualizarVencimentoRevisao('revisao');
}

function mostrarCaixaRenovarData(code){
  document.getElementById('renovar-caixa').style.display='block';
  document.getElementById('revisao-caixa-extra').style.display='none';
  atualizarVencimentoRevisao('renovar');
}

function atualizarVencimentoRevisao(prefix){
  const raw = document.getElementById(`${prefix==='revisao'?'revisao':'renovar'}-data-inicio`)?.value;
  const vencEl = document.getElementById(`${prefix==='revisao'?'revisao':'renovar'}-vencimento`);
  const labelEl = document.getElementById(`${prefix==='revisao'?'revisao':'renovar'}-venc-label`);
  const diasEl = document.getElementById(`${prefix==='revisao'?'revisao':'renovar'}-dias-label`);
  if(!raw || !vencEl) return;
  const d = new Date(raw+'T00:00:00');
  const venc = new Date(d); venc.setFullYear(venc.getFullYear()+5);
  const vencStr = venc.toLocaleDateString('pt-BR');
  vencEl.value = vencStr;
  if(labelEl) labelEl.textContent = vencStr;
  const dias = Math.ceil((venc - new Date()) / 86400000);
  if(diasEl){
    if(dias<0){ diasEl.textContent=`Vencido há ${Math.abs(dias)} dias`; diasEl.style.color='var(--red)'; }
    else if(dias<=90){ diasEl.textContent=`⚠ ${dias} dias restantes`; diasEl.style.color='var(--orange)'; }
    else { diasEl.textContent=`✓ ${dias} dias restantes`; diasEl.style.color='var(--green)'; }
  }
}

function confirmarRevisao(code, changed){
  const pop=POPS.find(p=>p.code===code);
  if(!pop)return;
  let count=0;

  // Get the date input based on which form was shown
  const dataInicioRaw = changed
    ? document.getElementById('revisao-data-inicio')?.value
    : document.getElementById('renovar-data-inicio')?.value;

  let dataInicio, dataVencimento;
  if(dataInicioRaw){
    const d = new Date(dataInicioRaw+'T00:00:00');
    dataInicio = d.toLocaleDateString('pt-BR');
    const venc = new Date(d); venc.setFullYear(venc.getFullYear()+5);
    dataVencimento = venc.toLocaleDateString('pt-BR');
  } else {
    dataInicio = new Date().toLocaleDateString('pt-BR');
    const venc = new Date(); venc.setFullYear(venc.getFullYear()+5);
    dataVencimento = venc.toLocaleDateString('pt-BR');
  }

  if(changed){
    TRAINING_MATRIX.forEach(r=>{const idx=r.pops.indexOf(code);if(idx!==-1){r.status[idx]='SOLICITADO';count++;}});
    pop.training='SOLICITADO';
    pop.vigencia='NO PRAZO';
    pop.docStatus='APROVADO';
    const mudancas=document.getElementById('revisao-mudancas');
    if(mudancas&&mudancas.value.trim()){pop.mudancas=mudancas.value.trim();}
  }
  pop.dataRevisao=dataInicio;
  pop.dataVencimento=dataVencimento;
  pop.vigencia='NO PRAZO';
  addLog(`POP Revisado: ${code}`, 'edit', `${pop.desc} · ${changed?'Com mudanças':'Renovação de data'} · Venc: ${dataVencimento}`);
  saveData();
  closeModal();
  setTimeout(()=>openModal('✅ Revisão <span>Concluída</span>',`
    <div style="text-align:center;padding:20px 0">
      <div style="font-size:3rem;margin-bottom:12px"></div>
      <div style="font-size:var(--fs-lg);font-weight:700;color:var(--green);margin-bottom:8px">Revisão registrada!</div>
      <div style="font-size:var(--fs-base);color:var(--gray-soft);margin-bottom:8px">${changed?`Procedimento atualizado. <strong>${count} cargo(s)</strong> marcados para novo treinamento.`:`Data renovada com sucesso.`}</div>
      <div style="display:inline-flex;align-items:center;gap:8px;padding:10px 18px;background:var(--green-bg);border-radius:var(--r);border:1.5px solid #b8dbd8">
        <span>Início:</span><strong>${dataInicio}</strong>
        <span style="color:var(--gray-soft)">·</span>
        <span>Vencimento:</span><strong style="color:var(--green)">${dataVencimento}</strong>
      </div>
      <button class="btn btn-primary" style="margin-top:20px;display:block;width:100%" onclick="closeModal();renderPOPs()">OK</button>
    </div>
  `),100);
}

function openPOPEmployees(code){
  const pop=POPS.find(p=>p.code===code);
  if(!pop)return;
  const matrixRoles=TRAINING_MATRIX.filter(r=>r.pops.includes(code));
  const roleNames=matrixRoles.map(r=>r.role.toUpperCase());
  const linked=EMPLOYEES.filter(e=>{
    const roleUp=e.role.toUpperCase();
    return roleNames.some(rn=>roleUp.includes(rn)||rn.includes(roleUp))||e.sector.toLowerCase()===pop.sectorName.toLowerCase();
  });
  const tableRows=linked.length?linked.map(emp=>{
    const relPOP=emp.pops.find(p=>p.pop.toLowerCase().includes(pop.desc.split(' ')[0].toLowerCase()));
    const badge=relPOP?empStatusBadge(relPOP.status):'<span class="badge badge-gray">Sem registro</span>';
    return`<tr class="clickable-row" onclick="closeModal();setTimeout(()=>openEmpProfile(${emp.id}),100)">
      <td><div style="display:flex;align-items:center;gap:10px"><div style="width:30px;height:30px;border-radius:50%;background:var(--red);display:flex;align-items:center;justify-content:center;color:white;font-weight:800;font-size:.7rem;flex-shrink:0">${emp.name.charAt(0)}</div><div><div style="font-weight:700;font-size:var(--fs-sm)">${emp.name}</div><div style="font-size:var(--fs-xs);color:var(--gray-soft)">${emp.email}</div></div></div></td>
      <td><span class="badge badge-blue">${emp.sector}</span></td>
      <td style="font-size:var(--fs-sm)">${emp.role}</td>
      <td>${badge}</td>
    </tr>`;
  }).join(''):`<tr><td colspan="4" style="text-align:center;padding:24px;color:var(--gray-soft)">Nenhum funcionário vinculado.</td></tr>`;

  openModalWide(`Funcionários — <span>${code}</span>`,`
    <div style="padding:12px 14px;background:var(--red-pale);border-radius:var(--r);margin-bottom:16px;border-left:3px solid var(--red)">
      <div style="font-weight:700">${pop.desc}</div>
      <div style="font-size:var(--fs-xs);color:var(--gray-soft);margin-top:4px">${pop.sectorName}</div>
    </div>
    <table class="data-table" style="min-width:500px"><thead><tr><th>Colaborador</th><th>Setor</th><th>Cargo</th><th>Status</th></tr></thead><tbody>${tableRows}</tbody></table>
  `);
}

function openPOPAnexos(code){
  const relAnexos=ANEXOS.filter(a=>a.popVinculado===code);
  const pop=POPS.find(p=>p.code===code);
  openModal(`Anexos — <span>${code}</span>`,`
    <div style="padding:12px;background:var(--red-pale);border-radius:var(--r);margin-bottom:14px;border-left:3px solid var(--red);font-weight:700;font-size:var(--fs-sm)">${pop?pop.desc:code}</div>
    ${relAnexos.length?`<table class="data-table"><thead><tr><th>Nome</th><th>Nº</th><th>Status</th><th>Criado</th></tr></thead><tbody>
      ${relAnexos.map(a=>{const sb=a.status==='Aprovado'?'<span class="badge badge-green">✓</span>':a.status==='Em Revisão'?'<span class="badge badge-orange">Rev.</span>':'<span class="badge badge-gray">Obs.</span>';return`<tr><td><strong>${a.nome}</strong></td><td>${a.numero}</td><td>${sb}</td><td style="font-size:var(--fs-xs)">${a.dataCriacao}</td></tr>`;}).join('')}
    </tbody></table>`:'<div style="color:var(--gray-soft);padding:20px;text-align:center">Nenhum anexo vinculado.</div>'}
    <div style="margin-top:12px;display:flex;gap:8px">
      <button class="btn btn-primary btn-sm" onclick="closeModal();setTimeout(openCriarAnexo,100)">+ Criar Anexo</button>
      <button class="btn btn-outline btn-sm" onclick="closeModal();navigate('anexos')">Ver todos</button>
    </div>
  `);
}

function openRevisaoGeral(){
  const needRevision=POPS.filter(p=>p.vigencia==='VENCIDO'||p.vigencia==='VENCE EM 3 MESES'||p.docStatus==='EM REVISÃO');
  openModalWide('🔄 Revisar <span>POPs</span>',`
    <div style="margin-bottom:14px;padding:12px 14px;background:var(--orange-bg);border-radius:var(--r);border-left:3px solid var(--orange);font-size:var(--fs-sm)"><strong>${needRevision.length} POP(s)</strong> necessitam atenção.</div>
    <table class="data-table"><thead><tr><th>Código</th><th>Descrição</th><th>Setor</th><th>Status</th><th>Vigência</th><th>Ação</th></tr></thead><tbody>
      ${needRevision.map(p=>`<tr>
        <td><strong style="color:var(--red)">${p.code}</strong></td>
        <td style="font-size:var(--fs-sm)">${p.desc}</td>
        <td><span class="badge badge-gray">${p.sectorName}</span></td>
        <td>${docBadge(p.docStatus)}</td>
        <td>${vigenciaBadge(p.vigencia)}</td>
        <td style="white-space:nowrap">
          <button class="btn btn-sm btn-primary" onclick="closeModal();setTimeout(()=>openRevisao('${p.code}'),100)">Revisar</button>
          <button class="btn btn-sm btn-danger" style="margin-left:4px" onclick="closeModal();deletePOP('${p.code}')">Excluir</button>
        </td>
      </tr>`).join('')}
    </tbody></table>
    ${!needRevision.length?'<div style="text-align:center;padding:24px;color:var(--green);font-weight:700">✅ Todos os POPs estão em conformidade!</div>':''}
  `);
}