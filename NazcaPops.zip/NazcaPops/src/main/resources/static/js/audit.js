/* ══════════════════════════════════════════
   AUDIT LOGS
══════════════════════════════════════════ */
let LOGS = [];

function addLog(action, type, detail) {
  LOGS.unshift({
    action,
    type, // 'create' | 'edit' | 'delete'
    detail,
    user: currentUser ? currentUser.name : 'Sistema',
    ts: new Date().toLocaleString('pt-BR')
  });
  saveData();
}

function renderAuditoria() {
  const typeFilter = document.getElementById('audit-type-filter')?.value || '';
  const filtered = typeFilter ? LOGS.filter(l => l.type === typeFilter) : LOGS;

  const creates = LOGS.filter(l=>l.type==='create').length;
  const edits   = LOGS.filter(l=>l.type==='edit').length;
  const deletes = LOGS.filter(l=>l.type==='delete').length;

  document.getElementById('audit-kpi-row').innerHTML = `
    <div class="kpi-card green glass-card" style="cursor:pointer" onclick="filterAuditByType('create')"><div class="kpi-val">${creates}</div><div class="kpi-label">Criações</div><div class="kpi-trend" style="color:var(--green)">${creates>0?'Clique para filtrar':'Nenhum registro'}</div></div>
    <div class="kpi-card blue glass-card" style="cursor:pointer" onclick="filterAuditByType('edit')"><div class="kpi-val">${edits}</div><div class="kpi-label">Edições</div><div class="kpi-trend" style="color:var(--blue)">${edits>0?'Clique para filtrar':'Nenhum registro'}</div></div>
    <div class="kpi-card glass-card" style="cursor:pointer" onclick="filterAuditByType('delete')"><div class="kpi-val">${deletes}</div><div class="kpi-label">Exclusões</div><div class="kpi-trend danger">${deletes>0?'Clique para filtrar':'Nenhum registro'}</div></div>
  `;

  const icons = {create:'+', edit:'✎', delete:'✕'};
  document.getElementById('audit-log-list').innerHTML = filtered.length
    ? filtered.map(l=>`
      <div class="log-entry ${l.type}">
        <div class="log-icon" style="font-style:normal;font-weight:800;font-size:1rem">${icons[l.type]||'·'}</div>
        <div class="log-body">
          <div class="log-action">${l.action}</div>
          <div class="log-detail">${l.detail}</div>
        </div>
        <div class="log-meta"><div>${l.user}</div><div>${l.ts}</div></div>
      </div>`).join('')
    : '<div style="text-align:center;padding:40px;color:var(--gray-soft)">Nenhum evento registrado ainda.</div>';
}

function filterAuditByType(type) {
  const sel = document.getElementById('audit-type-filter');
  if (sel) {
    // Toggle: if already filtering this type, clear filter
    sel.value = sel.value === type ? '' : type;
    renderAuditoria();
  }
}

function limparLogs() {
  showConfirm('Limpar Logs', 'Tem certeza que deseja apagar todo o histórico de auditoria?', () => {
    LOGS = [];
    saveData();
    renderAuditoria();
    toast('Logs apagados', 'Histórico de auditoria limpo.', 'info');
  });
}