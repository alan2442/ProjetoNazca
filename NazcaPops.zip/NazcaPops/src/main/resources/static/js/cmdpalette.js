/* ══════════════════════════════════════════
   FEATURE 2: CMD+K GLOBAL SEARCH PALETTE
══════════════════════════════════════════ */
let _cmdActiveIdx = -1;

function openCmdPalette() {
  document.getElementById('cmd-palette-overlay').classList.add('open');
  document.getElementById('cmd-palette-input').value = '';
  _cmdActiveIdx = -1;
  updateCmdResults();
  setTimeout(() => document.getElementById('cmd-palette-input').focus(), 60);
}

function closeCmdPalette() {
  document.getElementById('cmd-palette-overlay').classList.remove('open');
}

function updateCmdResults() {
  const q = (document.getElementById('cmd-palette-input').value || '').toLowerCase().trim();
  const container = document.getElementById('cmd-results');
  _cmdActiveIdx = -1;

  if (!q) {
    container.innerHTML = `<div class="cmd-empty">Digite para buscar POPs, funcionários e anexos...</div>`;
    return;
  }

  const popResults = POPS.filter(p =>
    p.code.toLowerCase().includes(q) ||
    p.desc.toLowerCase().includes(q) ||
    p.sectorName.toLowerCase().includes(q)
  ).slice(0, 5);

  const empResults = EMPLOYEES.filter(e =>
    e.name.toLowerCase().includes(q) ||
    e.role.toLowerCase().includes(q) ||
    e.sector.toLowerCase().includes(q)
  ).slice(0, 4);

  const anexoResults = ANEXOS.filter(a =>
    a.nome.toLowerCase().includes(q) ||
    a.popVinculado.toLowerCase().includes(q) ||
    a.desc.toLowerCase().includes(q)
  ).slice(0, 3);

  let html = '';

  if (popResults.length) {
    html += `<div class="cmd-result-group">📋 POPs (${popResults.length})</div>`;
    popResults.forEach((p, i) => {
      html += `<div class="cmd-result-item" data-idx="${i}" onclick="closeCmdPalette();navigate('pops');setTimeout(()=>openPOPDetail('${p.code}'),200)">
        <div class="cmd-result-icon">${p.popType === 'core' ? '⭐' : p.popType === 'area' ? '📂' : '🔧'}</div>
        <div style="flex:1;min-width:0">
          <div class="cmd-result-title">${p.code} — ${p.desc.substring(0, 45)}${p.desc.length > 45 ? '…' : ''}</div>
          <div class="cmd-result-sub">${p.sectorName}</div>
        </div>
        <div class="cmd-result-badge">${docBadge(p.docStatus)}</div>
      </div>`;
    });
  }

  if (empResults.length) {
    html += `<div class="cmd-result-group">👥 Funcionários (${empResults.length})</div>`;
    empResults.forEach(e => {
      html += `<div class="cmd-result-item" onclick="closeCmdPalette();navigate('funcionarios');setTimeout(()=>openEmpProfile(${e.id}),200)">
        <div class="cmd-result-icon" style="background:var(--red);color:white;font-weight:800;font-size:.75rem">${e.name.charAt(0)}</div>
        <div style="flex:1">
          <div class="cmd-result-title">${e.name}</div>
          <div class="cmd-result-sub">${e.role} · ${e.sector}</div>
        </div>
      </div>`;
    });
  }

  if (anexoResults.length) {
    html += `<div class="cmd-result-group">📎 Anexos (${anexoResults.length})</div>`;
    anexoResults.forEach(a => {
      html += `<div class="cmd-result-item" onclick="closeCmdPalette();navigate('anexos')">
        <div class="cmd-result-icon">📎</div>
        <div style="flex:1">
          <div class="cmd-result-title">${a.nome}</div>
          <div class="cmd-result-sub">Nº ${a.numero} · ${a.popVinculado}</div>
        </div>
      </div>`;
    });
  }

  if (!html) html = `<div class="cmd-empty">Nenhum resultado para "<strong>${q}</strong>"</div>`;
  container.innerHTML = html;
}

function cmdPaletteKey(e) {
  if (e.key === 'Escape') { closeCmdPalette(); return; }
  const items = document.querySelectorAll('#cmd-results .cmd-result-item');
  if (!items.length) return;
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    _cmdActiveIdx = Math.min(_cmdActiveIdx + 1, items.length - 1);
    items.forEach((el, i) => el.classList.toggle('active', i === _cmdActiveIdx));
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    _cmdActiveIdx = Math.max(_cmdActiveIdx - 1, 0);
    items.forEach((el, i) => el.classList.toggle('active', i === _cmdActiveIdx));
  } else if (e.key === 'Enter' && _cmdActiveIdx >= 0) {
    items[_cmdActiveIdx].click();
  }
}