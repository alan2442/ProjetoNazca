/* ══════════════════════════════════════════
   FILE ICON HELPER
══════════════════════════════════════════ */
function fileIcon(type) {
  if (!type) return {cls:'other', icon:'📄'};
  if (type.includes('pdf')) return {cls:'pdf', icon:'📕'};
  if (type.startsWith('image/')) return {cls:'img', icon:'🖼'};
  if (type.includes('word') || type.includes('document')) return {cls:'doc', icon:'📝'};
  if (type.includes('sheet') || type.includes('excel') || type.includes('csv')) return {cls:'xls', icon:'📊'};
  return {cls:'other', icon:'📄'};
}

function formatBytes(bytes) {
  if (!bytes) return '';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes/1024).toFixed(1) + ' KB';
  return (bytes/1048576).toFixed(1) + ' MB';
}


/* ══════════════════════════════════════════
   DATE HELPERS
══════════════════════════════════════════ */
function brToIso(br){
  if(!br||!br.includes('/'))return '';
  const [d,m,y]=br.split('/');
  return `${y}-${m.padStart(2,'0')}-${d.padStart(2,'0')}`;
}
function isoToBr(iso){
  if(!iso)return '';
  const [y,m,d]=iso.split('-');
  return `${d}/${m}/${y}`;
}




function calcDaysUntilExpiry(pop) {
  // Priority: use explicit dataVencimento if stored, else compute from dataRevisao (legacy 2yr) or dataCriacao (5yr)
  const parseDate = str => {
    if(!str || str==='—') return null;
    const p = str.split('/');
    if(p.length!==3) return null;
    return new Date(p[2], p[1]-1, p[0]);
  };
  let expiry = null;
  if(pop.dataVencimento) {
    expiry = parseDate(pop.dataVencimento);
  } else if(pop.dataCriacao) {
    const base = parseDate(pop.dataCriacao);
    if(base){ expiry = new Date(base); expiry.setFullYear(expiry.getFullYear()+5); }
  } else if(pop.dataRevisao) {
    const base = parseDate(pop.dataRevisao);
    if(base){ expiry = new Date(base); expiry.setFullYear(expiry.getFullYear()+2); }
  }
  if(!expiry) return null;
  return Math.ceil((expiry - new Date()) / 86400000);
}

function daysBadge(pop) {
  const d = calcDaysUntilExpiry(pop);
  if (d === null) return '<span class="days-badge na">—</span>';
  if (d < 0) return `<span class="days-badge overdue">${Math.abs(d)}d atrás</span>`;
  if (d <= 90) return `<span class="days-badge soon">${d}d</span>`;
  return `<span class="days-badge ok">✓ ${d}d</span>`;
}