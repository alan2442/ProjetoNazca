/* ══════════════════════════════════════════
   ALERTAS PAGE
══════════════════════════════════════════ */
function renderAlertasPage(){
  const content=document.getElementById('alertas-page-content');
  if(!content)return;
  const critical=POPS.filter(p=>p.vigencia==='VENCIDO'||p.docStatus==='ELABORAR');
  const expiring=POPS.filter(p=>p.vigencia==='VENCE EM 3 MESES');
  const pending=POPS.filter(p=>p.training==='SOLICITADO');
  content.innerHTML=`
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin-bottom:20px">
      <div class="kpi-card"><div class="kpi-val" style="color:var(--red)">${critical.length}</div><div class="kpi-label">POPs Críticos</div></div>
      <div class="kpi-card orange"><div class="kpi-val">${expiring.length}</div><div class="kpi-label">Vencendo em 3 Meses</div></div>
      <div class="kpi-card blue"><div class="kpi-val">${pending.length}</div><div class="kpi-label">Treinamentos Pendentes</div></div>
    </div>
    <div class="bento-card col-12" style="margin-bottom:16px">
      <h3><span>🚨</span> POPs que exigem ação imediata</h3>
      ${critical.map(p=>{
        const d=calcDaysUntilExpiry(p);
        const dStr=d!==null?(d<0?`<span class="days-badge overdue">⚠ Vencido há ${Math.abs(d)}d</span>`:`<span class="days-badge soon">${d}d restantes</span>`):'';
        return`
        <div class="alert-item danger" onclick="closeModal();navigate('pops')">
          <span class="alert-item-icon" style="color:var(--red);font-weight:900">!</span>
          <div class="alert-item-text"><strong>${p.code}</strong> — ${p.desc}<div style="font-size:var(--fs-xs);color:var(--gray-soft);margin-top:2px">${p.sectorName} · ${p.vigencia} ${dStr}</div></div>
          <div style="display:flex;gap:6px">
            ${docBadge(p.docStatus)}
            <button class="btn btn-danger btn-sm" onclick="event.stopPropagation();deletePOP('${p.code}')">Excluir</button>
          </div>
        </div>
      `}).join('')}
      ${!critical.length?'<div style="color:var(--green);font-weight:700;padding:12px">✅ Nenhum POP crítico.</div>':''}
    </div>
    <div class="bento-card col-12">
      <h3><span>⏳</span> Treinamentos Solicitados</h3>
      ${pending.map(p=>`
        <div class="alert-item warn">
          <span class="alert-item-icon" style="color:var(--orange);font-weight:900">!</span>
          <div class="alert-item-text"><strong>${p.code}</strong> — ${p.desc}<div style="font-size:var(--fs-xs);color:var(--gray-soft);margin-top:2px">${p.sectorName}</div></div>
          <div style="display:flex;gap:6px">
            ${trainBadge(p.training)}
            <button class="btn btn-danger btn-sm" onclick="deletePOP('${p.code}');renderAlertasPage()">Excluir</button>
          </div>
        </div>
      `).join('')}
      ${!pending.length?'<div style="color:var(--green);font-weight:700;padding:12px">✅ Nenhum treinamento pendente.</div>':''}
    </div>
  `;
}