let currentUser = null;


let EMPLOYEES = [
  {id:1,name:'Ana Beatriz Lima',email:'ana.lima@nazca.com',sector:'Qualidade de Vida',role:'Auxiliar de Qualidade',admission:'2025-06-01',pops:[
    {pop:'Higiene e Manipulação de Alimentos',version:'2.0',status:'Válido',days:305,type:'core'},
    {pop:'Uso de EPI e Segurança no Trabalho',version:'1.0',status:'Crítico',days:25,type:'core'},
    {pop:'Controle de Qualidade e Inspeção',version:'3.0',status:'Vencido',days:-15,type:'area'},
    {pop:'Gestão de Resíduos',version:'1.0',status:'Válido',days:275,type:'area'},
    {pop:'Atendimento e Bem-Estar do Colaborador',version:'1.0',status:'Pendente',days:null,type:'cargo'},
  ]},
  {id:2,name:'Carlos Eduardo Silva',email:'carlos.silva@nazca.com',sector:'Qualidade de Vida',role:'Supervisor de Higiene',admission:'2024-03-15',pops:[
    {pop:'Higiene e Manipulação de Alimentos',version:'2.0',status:'Revisão Pendente',days:-35,type:'core'},
    {pop:'Uso de EPI e Segurança no Trabalho',version:'1.0',status:'Válido',days:245,type:'core'},
    {pop:'Controle de Qualidade e Inspeção',version:'3.0',status:'Crítico',days:10,type:'area'},
    {pop:'Gestão de Resíduos',version:'1.0',status:'Pendente',days:null,type:'area'},
    {pop:'Atendimento e Bem-Estar do Colaborador',version:'1.0',status:'Pendente',days:null,type:'cargo'},
  ]},
  {id:3,name:'Mariana Costa',email:'mariana.costa@nazca.com',sector:'Nutrição',role:'Nutricionista',admission:'2024-08-01',pops:[
    {pop:'Higiene e Manipulação de Alimentos',version:'2.0',status:'Válido',days:165,type:'core'},
  ]},
  {id:4,name:'Pedro Henrique Santos',email:'pedro.santos@nazca.com',sector:'Operações',role:'Gerente Operacional',admission:'2023-11-01',pops:[
    {pop:'Uso de EPI e Segurança no Trabalho',version:'1.0',status:'Vencido',days:-5,type:'core'},
    {pop:'Gestão de Resíduos',version:'1.0',status:'Pendente',days:null,type:'area'},
  ]},
  {id:5,name:'Fernanda Oliveira',email:'f.oliveira@nazca.com',sector:'Segurança do Trabalho',role:'Técnica de Segurança',admission:'2025-01-10',pops:[
    {pop:'Uso de EPI e Segurança no Trabalho',version:'1.0',status:'Válido',days:215,type:'core'},
  ]},
  {id:6,name:'Rafael Mendes',email:'r.mendes@nazca.com',sector:'Administrativo',role:'Auxiliar Administrativo',admission:'2025-09-01',pops:[
    {pop:'LGPD — Proteção de Dados',version:'2.0',status:'Válido',days:315,type:'core'},
  ]},
  {id:7,name:'Juliana Ferreira',email:'j.ferreira@nazca.com',sector:'RH',role:'Coordenadora de RH',admission:'2023-05-01',pops:[
    {pop:'Atendimento e Bem-Estar do Colaborador',version:'1.0',status:'Válido',days:335,type:'core'},
    {pop:'LGPD — Proteção de Dados',version:'2.0',status:'Revisão Pendente',days:-35,type:'area'},
  ]},
  {id:8,name:'Bruno Alves',email:'b.alves@nazca.com',sector:'Jurídico',role:'Analista Jurídico',admission:'2024-02-01',pops:[
    {pop:'LGPD — Proteção de Dados',version:'2.0',status:'Válido',days:265,type:'core'},
  ]},
  {id:9,name:'Larissa Rocha',email:'l.rocha@nazca.com',sector:'Qualidade de Vida',role:'Auxiliar de Qualidade',admission:'2026-04-01',pops:[
    {pop:'Higiene e Manipulação de Alimentos',version:'2.0',status:'Pendente',days:null,type:'core'},
    {pop:'Uso de EPI e Segurança no Trabalho',version:'1.0',status:'Pendente',days:null,type:'core'},
    {pop:'Controle de Qualidade e Inspeção',version:'3.0',status:'Pendente',days:null,type:'area'},
    {pop:'Gestão de Resíduos',version:'1.0',status:'Pendente',days:null,type:'area'},
    {pop:'Atendimento e Bem-Estar do Colaborador',version:'1.0',status:'Pendente',days:null,type:'cargo'},
  ]},
  {id:10,name:'Mikaela Santos',email:'mikaela@nazca.com',sector:'Qualidade de Vida',role:'Gestora de Qualidade de Vida',admission:'2024-01-15',pops:[
    {pop:'Higiene e Manipulação de Alimentos',version:'2.0',status:'Válido',days:345,type:'core'},
    {pop:'Uso de EPI e Segurança no Trabalho',version:'1.0',status:'Válido',days:340,type:'core'},
    {pop:'Controle de Qualidade e Inspeção',version:'3.0',status:'Válido',days:350,type:'area'},
    {pop:'Gestão de Resíduos',version:'1.0',status:'Válido',days:347,type:'area'},
    {pop:'Atendimento e Bem-Estar do Colaborador',version:'1.0',status:'Válido',days:343,type:'core'},
  ]},
];



let ANEXOS = [
  {id:1,nome:'Procedimento de Limpeza CQ 033',numero:'I',popVinculado:'CQ 033',desc:'Instruções detalhadas de limpeza e sanitização da Estufa Fabbe, incluindo frequência e produtos aprovados.',status:'Aprovado',dataCriacao:'20/06/2021',dataRevisao:'20/06/2023'},
  {id:2,nome:'Ficha de Calibração pHmetro',numero:'II',popVinculado:'CQ 008',desc:'Planilha de registros de calibração diária do pHmetro Q400AS com valores de referência e tolerâncias.',status:'Em Revisão',dataCriacao:'05/02/2022',dataRevisao:'05/02/2025'},
  {id:3,nome:'Instrução de Uso de Empilhadeira',numero:'III',popVinculado:'AL 002',desc:'Manual operacional simplificado para empilhadeira do almoxarifado, incluindo checklist de segurança.',status:'Aprovado',dataCriacao:'15/03/2023',dataRevisao:'15/03/2025'},
  {id:4,nome:'Registro de Recebimento de MP',numero:'IV',popVinculado:'AL 001',desc:'Formulário padrão para registro de entrada e inspeção de matéria-prima e embalagens.',status:'Obsoleto',dataCriacao:'10/01/2023',dataRevisao:'10/01/2025'},
];


const TRAINING_MATRIX = [
  {role:'ANALISTA DE CONTROLE DE QUALIDADE',sector:'Qualidade',pops:['AL 001','CQ 005','CQ 006','CQ 008','CQ 009','CQ 010','CQ 012','CQ 017'],status:['OK','OK','OK','OK','OK','SOLICITADO','OK','OK']},
  {role:'ASSISTENTE DA QUALIDADE',sector:'Qualidade',pops:['CQ 005','CQ 006','CQ 007','CQ 008','CQ 009','CQ 010','CQ 012','CQ 017'],status:['OK','OK','OK','OK','OK','SOLICITADO','OK','OK']},
  {role:'ANALISTA DA GARANTIA DA QUALIDADE',sector:'Qualidade',pops:['CQ 005','CQ 006','CQ 008','CQ 009','CQ 010','CQ 011','CQ 012','CQ 017'],status:['OK','OK','OK','OK','OK','OK','OK','OK']},
  {role:'ANALISTA DE LABORATÓRIO',sector:'Qualidade',pops:['CQ 005','CQ 006','CQ 007','CQ 008','CQ 010','CQ 012','CQ 013','CQ 017'],status:['OK','OK','OK','OK','SOLICITADO','OK','OK','OK']},
  {role:'ESTAGIÁRIO (Qualidade)',sector:'Qualidade',pops:['CQ 005','CQ 007','CQ 008','CQ 009','CQ 010'],status:['OK','OK','OK','OK','SOLICITADO']},
  {role:'ASSISTENTE ADM ALMOXARIFADO',sector:'Almoxarifado',pops:['AL 001','AL 002','AL 003'],status:['OK','OK','OK']},
  {role:'AUXILIAR DE ALMOXARIFADO',sector:'Almoxarifado',pops:['AL 001','AL 002','AL 003'],status:['OK','SOLICITADO','OK']},
  {role:'OPERADOR DE EMPILHADEIRA',sector:'Almoxarifado',pops:['AL 001','AL 002','AL 003'],status:['OK','OK','OK']},
  {role:'ANALISTA DE PCP',sector:'PCP',pops:['AL 001','CQ 012'],status:['OK','OK']},
  {role:'LÍDER DE PRODUÇÃO',sector:'Produção',pops:['CQ 006','CQ 010','CQ 012'],status:['OK','SOLICITADO','OK']},
  {role:'OPERADOR DE PRODUÇÃO',sector:'Produção',pops:['CQ 006','CQ 012'],status:['OK','OK']},
  {role:'AUXILIAR DE MANIPULAÇÃO',sector:'Manipulação',pops:['CQ 010'],status:['SOLICITADO']},
  {role:'PESQUISADOR JÚNIOR',sector:'P&D',pops:['CQ 010','DP 002','DP 003','DP 007'],status:['OK','OK','SOLICITADO','SOLICITADO']},
  {role:'ASSISTENTE DE P&D',sector:'P&D',pops:['CQ 007','CQ 010','DP 002','DP 003','DP 004','DP 007'],status:['OK','OK','OK','SOLICITADO','SOLICITADO','SOLICITADO']},
  {role:'ANALISTA DE DESIGN',sector:'Des. Embalagem',pops:['DE 001','DE 004','DE 005','DE 006'],status:['OK','OK','OK','OK']},
];

const CORE_POPS = ['AL 001','CQ 010','CQ 012','CQ 017'];


const MATRIX_POPS = ['AL 001','AL 002','AL 003','CQ 005','CQ 006','CQ 007','CQ 008','CQ 009','CQ 010','CQ 012','CQ 013','CQ 017','DE 001','DP 002','DP 007'];


const ONBOARDING_MAP = {
  'Qualidade de Vida':['Higiene e Manipulação de Alimentos','Uso de EPI e Segurança no Trabalho','Gestão de Resíduos','Controle de Qualidade e Inspeção','Atendimento e Bem-Estar do Colaborador'],
  'Operações':['Uso de EPI e Segurança no Trabalho','Gestão de Resíduos'],
  'Segurança do Trabalho':['Uso de EPI e Segurança no Trabalho'],
  'Nutrição':['Higiene e Manipulação de Alimentos'],
  'RH':['Atendimento e Bem-Estar do Colaborador','LGPD — Proteção de Dados'],
  'Jurídico':['LGPD — Proteção de Dados'],
  'Administrativo':['LGPD — Proteção de Dados'],
};


let nextEmpId = 11;


let nextAnexoId = 5;