/* ══════════════════════════════════════════
   AUTH
══════════════════════════════════════════ */
const VALID_USERS = [
  { email:'admin@nazca.com', pass:'nazca2024', name:'Admin', role:'Administrador' },
  { email:'qualidade@nazca.com', pass:'cq2024', name:'Analista CQ', role:'Analista' },
];

let mfaCode = '';
let pendingUser = null;

function doLogin() {
  const email = document.getElementById('login-email').value.trim().toLowerCase();
  const pass  = document.getElementById('login-pass').value;
  const err   = document.getElementById('login-error');
  const user  = VALID_USERS.find(u => u.email === email && u.pass === pass);
  if (!user) {
    err.textContent = '❌ E-mail ou senha incorretos. Tente novamente.';
    err.style.display = 'block';
    return;
  }
  err.style.display = 'none';
  pendingUser = user;
  mfaCode = '123456'; // Demo fixed code
  document.getElementById('mfa-email-display').textContent = email.replace(/(.{2}).*(@)/, '$1***$2');
  document.getElementById('login-panel').style.display = 'none';
  document.getElementById('mfa-panel').style.display = 'block';
  document.getElementById('mfa0').focus();
}

function mfaInput(idx) {
  const val = document.getElementById('mfa'+idx).value.replace(/\D/g,'');
  document.getElementById('mfa'+idx).value = val;
  if (val && idx < 5) document.getElementById('mfa'+(idx+1)).focus();
  if (idx === 5 && val) doMFA();
}
function mfaKey(e, idx) {
  if (e.key === 'Backspace' && !document.getElementById('mfa'+idx).value && idx > 0)
    document.getElementById('mfa'+(idx-1)).focus();
}
function doMFA() {
  const code = [0,1,2,3,4,5].map(i=>document.getElementById('mfa'+i).value).join('');
  const err  = document.getElementById('mfa-error');
  if (code !== mfaCode) {
    err.textContent = '❌ Código inválido. O código demo é 123456.';
    err.style.display = 'block';
    [0,1,2,3,4,5].forEach(i=>{ document.getElementById('mfa'+i).value=''; });
    document.getElementById('mfa0').focus();
    return;
  }
  currentUser = pendingUser;
  loadData();
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('navbar').style.display = 'flex';
  const initials = currentUser.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
  document.getElementById('user-avatar').textContent = initials;
  document.getElementById('user-name-display').textContent = currentUser.name.split(' ')[0];
  navigate('dashboard');
  startLiveClock();
  setTimeout(()=>toast('Bem-vindo, '+currentUser.name.split(' ')[0]+'!', 'Dados carregados do armazenamento local.', 'success'), 400);
}
function resendMFA() {
  const resend = document.querySelector('.mfa-resend');
  resend.textContent = '✓ Código reenviado!';
  resend.style.color = '#5ecebf';
  setTimeout(() => { resend.textContent = 'Reenviar código'; resend.style.color = ''; }, 3000);
}
function doLogout() {
  currentUser = null;
  pendingUser = null;
  document.getElementById('login-screen').style.display = 'flex';
  document.getElementById('navbar').style.display = 'none';
  document.getElementById('login-panel').style.display = 'block';
  document.getElementById('mfa-panel').style.display = 'none';
  document.getElementById('login-pass').value = '';
  document.getElementById('login-error').style.display = 'none';
  [0,1,2,3,4,5].forEach(i=>{ document.getElementById('mfa'+i).value=''; });
  document.getElementById('mfa-error').style.display = 'none';
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById('page-dashboard').classList.add('active');
}

/* ══════════════════════════════════════════
   MOBILE NAV
══════════════════════════════════════════ */
function openMobileNav() {
  document.getElementById('mobile-nav-overlay').classList.add('open');
  document.getElementById('mobile-nav-panel').style.transform = 'translateX(0)';
}
function closeMobileNav() {
  document.getElementById('mobile-nav-overlay').classList.remove('open');
  document.getElementById('mobile-nav-panel').style.transform = 'translateX(100%)';
}

/* ══════════════════════════════════════════
   DATA
══════════════════════════════════════════ */
let POPS = [
  {code:'AL 001',type:'POP',popType:'core',sector:'AL',sectorName:'Almoxarifado',desc:'Recebimento e Armazenamento de MP e Embalagem',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK',dataCriacao:'10/01/2023',dataRevisao:'10/01/2025'},
  {code:'AL 002',type:'POP',popType:'area',sector:'AL',sectorName:'Almoxarifado',desc:'Utilização de Empilhadeira',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'SOLICITADO',dataCriacao:'15/03/2023',dataRevisao:'15/03/2025'},
  {code:'AL 003',type:'POP',popType:'area',sector:'AL',sectorName:'Almoxarifado',desc:'Separação de Embalagem e Semiacabado',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'SOLICITADO'},
  {code:'CQ 005',type:'POP',popType:'area',sector:'CQ',sectorName:'Qualidade',desc:'Amostragem e Análise de Água',docStatus:'EM REVISÃO',vigencia:'NO PRAZO',training:'OK'},
  {code:'CQ 006',type:'POP',popType:'area',sector:'CQ',sectorName:'Qualidade',desc:'Controle Estatístico de Processo',docStatus:'EM REVISÃO',vigencia:'NO PRAZO',training:'OK'},
  {code:'CQ 008',type:'POP',popType:'area',sector:'CQ',sectorName:'Qualidade',desc:'Calibração e Utilização pHmetro Q400AS',docStatus:'APROVADO',vigencia:'VENCE EM 3 MESES',training:'OK',dataCriacao:'05/02/2022',dataRevisao:'05/02/2025'},
  {code:'CQ 009',type:'POP',popType:'area',sector:'CQ',sectorName:'Qualidade',desc:'Preparo e Controle de Soluções e Reagentes',docStatus:'EM REVISÃO',vigencia:'NO PRAZO',training:'OK'},
  {code:'CQ 010',type:'POP',popType:'core',sector:'CQ',sectorName:'Qualidade',desc:'Análise e Liberação Físico-Química de PA',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'SOLICITADO'},
  {code:'CQ 012',type:'POP',popType:'core',sector:'CQ',sectorName:'Qualidade',desc:'Recebimento de Amostra e Controle de Retenção',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'CQ 013',type:'POP',popType:'cargo',sector:'CQ',sectorName:'Qualidade',desc:'Análise de Amostras de Enxague e Liberação',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'CQ 017',type:'POP',popType:'core',sector:'CQ',sectorName:'Qualidade',desc:'Boas Práticas e Segurança de Laboratório',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'CQ 018',type:'POP',popType:'cargo',sector:'CQ',sectorName:'Qualidade',desc:'Recebimento e Liberação de Material de Embalagem',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'SOLICITADO'},
  {code:'CQ 019',type:'POP',popType:'cargo',sector:'CQ',sectorName:'Qualidade',desc:'Recebimento e Liberação de Matéria Prima',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'SOLICITADO'},
  {code:'CQ 027',type:'POP',popType:'area',sector:'CQ',sectorName:'Qualidade',desc:'Limpeza e Utilização do Barrilete 20L',docStatus:'EM REVISÃO',vigencia:'NO PRAZO',training:'OK'},
  {code:'CQ 029',type:'POP',popType:'cargo',sector:'CQ',sectorName:'Qualidade',desc:'Inspeção de Qualidade em Linha',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'SOLICITADO'},
  {code:'CQ 033',type:'POP',popType:'area',sector:'CQ',sectorName:'Qualidade',desc:'Limpeza e Utilização da Estufa Fabbe',docStatus:'APROVADO',vigencia:'VENCIDO',training:'OK',dataCriacao:'20/06/2021',dataRevisao:'20/06/2023'},
  {code:'CQ 039',type:'POP',popType:'cargo',sector:'CQ',sectorName:'Qualidade',desc:'Resultado Fora de Especificação',docStatus:'ELABORAR',vigencia:'ELABORAR',training:'N.A'},
  {code:'CQ 040',type:'POP',popType:'area',sector:'CQ',sectorName:'Qualidade',desc:'Lançamento de Produtos Controlados',docStatus:'EM REVISÃO',vigencia:'NO PRAZO',training:'N.A'},
  {code:'DE 001',type:'POP',popType:'area',sector:'DE',sectorName:'Des. Embalagem',desc:'Desenvolvimento de Embalagem',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'DE 002',type:'POP',popType:'area',sector:'DE',sectorName:'Des. Embalagem',desc:'Teste de Embalagem em Linha',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'DE 003',type:'POP',popType:'area',sector:'DE',sectorName:'Des. Embalagem',desc:'Estudo de Compatibilidade de Embalagem',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'DE 004',type:'POP',popType:'cargo',sector:'DE',sectorName:'Des. Embalagem',desc:'Rotina do Desenvolvimento de Embalagens',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'DE 005',type:'POP',popType:'cargo',sector:'DE',sectorName:'Des. Embalagem',desc:'Etapas de Projetos de Novos Produtos',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'DE 007',type:'POP',popType:'cargo',sector:'DE',sectorName:'Des. Embalagem',desc:'Cadastro Nacional de Produtos - GS1',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'DP 001',type:'POP',popType:'area',sector:'DP',sectorName:'P&D',desc:'Limpeza e Sanitização Barrilete Desmineralizada',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'DP 002',type:'POP',popType:'area',sector:'DP',sectorName:'P&D',desc:'Transferência de Escala',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'OK'},
  {code:'DP 003',type:'POP',popType:'cargo',sector:'DP',sectorName:'P&D',desc:'Rotinas do Laboratório de P&D',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'SOLICITADO'},
  {code:'DP 004',type:'POP',popType:'cargo',sector:'DP',sectorName:'P&D',desc:'Manuseio e Limpeza do Reator de Inox 10kg',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'SOLICITADO'},
  {code:'DP 007',type:'POP',popType:'area',sector:'DP',sectorName:'P&D',desc:'Desenvolvimento de Formulações',docStatus:'APROVADO',vigencia:'NO PRAZO',training:'SOLICITADO'},
];

const SECTORS_DATA = {
  AL:{name:'Almoxarifado',total:3,approved:3,inReview:0,expired:0,trainPending:2},
  CQ:{name:'Qualidade / CQ',total:16,approved:10,inReview:4,expired:1,trainPending:5},
  DE:{name:'Des. Embalagem',total:6,approved:6,inReview:0,expired:0,trainPending:0},
  DP:{name:'P&D',total:5,approved:5,inReview:0,expired:0,trainPending:3},
};


const ALL_SECTORS = {
  AL:'Almoxarifado',
  CQ:'Qualidade / CQ',
  DE:'Des. Embalagem',
  DP:'P&D',
};

const ROLES_BY_SECTOR = {
  'Almoxarifado':['Assistente Adm Almoxarifado','Auxiliar de Almoxarifado','Operador de Empilhadeira'],
  'Qualidade / CQ':['Analista de Controle de Qualidade','Assistente da Qualidade','Analista da Garantia da Qualidade','Analista de Laboratório','Estagiário (Qualidade)'],
  'Des. Embalagem':['Analista de Design','Designer de Embalagem','Coordenador de Embalagem'],
  'P&D':['Pesquisador Júnior','Assistente de P&D','Analista de P&D'],
  'Qualidade de Vida':['Auxiliar de Qualidade','Supervisor de Higiene','Gestora de Qualidade de Vida'],
  'Nutrição':['Nutricionista','Auxiliar de Nutrição'],
  'Operações':['Gerente Operacional','Supervisor de Operações','Analista de PCP','Líder de Produção','Operador de Produção','Auxiliar de Manipulação'],
  'Segurança do Trabalho':['Técnica de Segurança','Engenheiro de Segurança'],
  'RH':['Coordenadora de RH','Analista de RH','Assistente de RH'],
  'Jurídico':['Analista Jurídico','Advogado'],
  'Administrativo':['Auxiliar Administrativo','Assistente Administrativo','Gerente Administrativo'],
  'Produção':['Líder de Produção','Operador de Produção','Auxiliar de Manipulação'],
  'Manipulação':['Auxiliar de Manipulação'],
  'PCP':['Analista de PCP'],
};











let currentSectorFilter = null;
let tvMode = false;
let chartsInit = {};
let confirmCallback = null;

/* ══════════════════════════════════════════
   CONFIRM DELETE
══════════════════════════════════════════ */
function showConfirm(title, msg, cb) {
  confirmCallback = cb;
  document.getElementById('confirm-title').textContent = title;
  document.getElementById('confirm-msg').textContent = msg;
  document.getElementById('confirm-yes-btn').onclick = () => { const fn = confirmCallback; closeConfirm(); if(fn) fn(); };
  document.getElementById('confirm-overlay').classList.add('open');
}
function closeConfirm() {
  document.getElementById('confirm-overlay').classList.remove('open');
  confirmCallback = null;
}

/* ══════════════════════════════════════════
   NAVIGATION
══════════════════════════════════════════ */
function navigate(page, sectorFilter) {
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.nb-link').forEach(l=>l.classList.remove('active'));
  document.getElementById('page-'+page).classList.add('active');
  document.querySelectorAll('.nb-link').forEach(l=>{
    const t=l.textContent.toLowerCase();
    if(page==='dashboard'&&t.includes('dashboard'))l.classList.add('active');
    if(page==='analytics'&&t.includes('analytics'))l.classList.add('active');
    if(page==='pops'&&t.includes('procedimentos'))l.classList.add('active');
    if(page==='funcionarios'&&t.includes('funcionários'))l.classList.add('active');
    if(page==='matriz'&&t.includes('matriz'))l.classList.add('active');
    if(page==='alertas'&&t.includes('alertas'))l.classList.add('active');
    if(page==='anexos'&&t.includes('anexos'))l.classList.add('active');
    if(page==='auditoria'&&t.includes('auditoria'))l.classList.add('active');
  });
  if(page==='dashboard'){renderDashboard();startLiveClock();}
  if(page==='analytics'){currentSectorFilter=sectorFilter||null;renderAnalytics();}
  if(page==='pops')renderPOPs();
  if(page==='funcionarios')renderFuncionarios();
  if(page==='matriz')renderMatrix();
  if(page==='anexos')renderAnexos();
  if(page==='alertas')renderAlertasPage();
  if(page==='auditoria')renderAuditoria();
}

/* ══════════════════════════════════════════
   DARK MODE
══════════════════════════════════════════ */
function toggleDarkMode() {
  tvMode=!tvMode;
  document.body.classList.toggle('dark-mode',tvMode);
  document.getElementById('tv-btn').classList.toggle('on',tvMode);
  Object.values(chartsInit).forEach(c=>{if(c&&c.destroy)c.destroy();});
  chartsInit={};
  const activePage=document.querySelector('.page.active');
  if(activePage){
    const id=activePage.id.replace('page-','');
    if(id==='dashboard')renderDashboard();
    if(id==='analytics')renderAnalytics();
  }
}

/* ══════════════════════════════════════════
   MODAL
══════════════════════════════════════════ */
function openModal(title,bodyHTML,wide){
  document.getElementById('modal-title').innerHTML=title;
  document.getElementById('modal-body').innerHTML=bodyHTML;
  document.querySelector('.modal-box').classList.toggle('modal-wide',!!wide);
  document.getElementById('modal').classList.add('open');
}
function openModalWide(t,b){openModal(t,b,true);}
function closeModal(){document.getElementById('modal').classList.remove('open');}

/* ══════════════════════════════════════════
   STATUS HELPERS
══════════════════════════════════════════ */
function vigenciaBadge(v){
  const m={'NO PRAZO':'<span class="badge badge-green">No Prazo</span>','VENCE EM 3 MESES':'<span class="badge badge-orange">Vence em 3m</span>','VENCIDO':'<span class="badge badge-red">Vencido ⚠</span>','OBSOLETO':'<span class="badge badge-gray">Obsoleto</span>','ELABORAR':'<span class="badge badge-sand">Elaborar</span>'};
  return m[v]||`<span class="badge badge-gray">${v}</span>`;
}
function docBadge(s){
  const m={'APROVADO':'<span class="badge badge-green">✓ Aprovado</span>','EM REVISÃO':'<span class="badge badge-orange">Em Revisão</span>','ELABORAR':'<span class="badge badge-sand">Elaborar</span>','OBSOLETO':'<span class="badge badge-gray">Obsoleto</span>'};
  return m[s]||`<span class="badge badge-gray">${s}</span>`;
}
function trainBadge(t){
  if(t==='OK')return'<span class="badge badge-green">✓ OK</span>';
  if(t==='SOLICITADO')return'<span class="badge badge-orange">⏳ Solicitado</span>';
  if(t==='N.A')return'<span class="badge badge-gray">N/A</span>';
  return`<span class="badge badge-gray">${t}</span>`;
}
function empStatusBadge(s){
  const m={'Válido':'<span class="badge badge-green">✓ Válido</span>','Crítico':'<span class="badge badge-orange">⚠ Crítico</span>','Vencido':'<span class="badge badge-red">Vencido</span>','Pendente':'<span class="badge badge-gray">Pendente</span>','Revisão Pendente':'<span class="badge badge-sand">Revisão</span>'};
  return m[s]||`<span class="badge badge-gray">${s}</span>`;
}
function popTypeBadge(t){
  if(t==='core')return'<span class="badge badge-blue">Core</span>';
  if(t==='area')return'<span class="badge badge-green">Área</span>';
  if(t==='cargo')return'<span class="badge badge-orange">Cargo</span>';
  return'<span class="badge badge-gray">POP</span>';
}
function empCompliance(emp){
  if(!emp.pops.length)return 0;
  return Math.round(emp.pops.filter(p=>p.status==='Válido').length/emp.pops.length*100);
}

/* ══════════════════════════════════════════
   DASHBOARD
══════════════════════════════════════════ */
function renderDashboard(){
  // Recompute SECTORS_DATA from live POPS array for real-time charts
  const sectorNames={AL:'Almoxarifado',CQ:'Qualidade / CQ',DE:'Des. Embalagem',DP:'P&D'};
  const sectors=[...new Set(POPS.map(p=>p.sector))];
  sectors.forEach(s=>{
    const sp=POPS.filter(p=>p.sector===s);
    SECTORS_DATA[s]={
      name:sectorNames[s]||s,
      total:sp.length,
      approved:sp.filter(p=>p.docStatus==='APROVADO').length,
      inReview:sp.filter(p=>p.docStatus==='EM REVISÃO').length,
      expired:sp.filter(p=>p.vigencia==='VENCIDO').length,
      trainPending:sp.filter(p=>p.training==='SOLICITADO').length,
    };
  });
  const totalPOPs=POPS.length;
  const approved=POPS.filter(p=>p.docStatus==='APROVADO').length;
  const compliance=Math.round(approved/totalPOPs*100);
  const critical=POPS.filter(p=>p.vigencia==='VENCIDO'||p.docStatus==='ELABORAR').length;
  const expiring=POPS.filter(p=>p.vigencia==='VENCE EM 3 MESES').length;
  const pendTrain=POPS.filter(p=>p.training==='SOLICITADO').length;

  document.getElementById('kpi-grid').innerHTML=`
    <div class="kpi-card green glass-card" onclick="navigate('analytics')"><div class="kpi-val">${compliance}%</div><div class="kpi-label">Compliance Global</div><div class="kpi-trend">▲ ${approved} de ${totalPOPs} POPs aprovados</div></div>
    <div class="kpi-card glass-card" onclick="showAlertasModal()"><div class="kpi-val">${critical}</div><div class="kpi-label">Alertas Críticos</div><div class="kpi-trend danger">${critical>0?'Ação imediata requerida':'Sem críticos'}</div></div>
    <div class="kpi-card orange glass-card" onclick="showPendenciasModal()"><div class="kpi-val">${expiring+pendTrain}</div><div class="kpi-label">Pendências Totais</div><div class="kpi-trend warn">${expiring} vencendo · ${pendTrain} trein. solicitados</div></div>
    <div class="kpi-card blue glass-card" onclick="navigate('funcionarios')"><div class="kpi-val">${EMPLOYEES.length}</div><div class="kpi-label">Colaboradores</div><div class="kpi-trend">Cobrindo ${Object.keys(SECTORS_DATA).length} setores ativos</div></div>
  `;
  document.getElementById('alert-badge').textContent=`${critical+expiring} Alertas`;

  document.getElementById('sector-table').innerHTML=Object.entries(SECTORS_DATA).map(([key,s])=>{
    const pct=Math.round(s.approved/s.total*100);
    const color=pct===100?'var(--green)':pct>=70?'var(--orange)':'var(--red)';
    return`<div class="sector-row">
      <span class="clickable" onclick="navigate('analytics','${key}')">${s.name}</span>
      <span style="text-align:center">${s.total}</span>
      <span style="text-align:center;color:var(--green);font-weight:700">${s.approved}</span>
      <span style="text-align:center;color:${(s.expired>0||s.inReview>2)?'var(--red)':'var(--gray-soft)'};font-weight:700" class="sector-col-3">${s.inReview+s.expired}</span>
      <div style="flex:1"><div style="display:flex;justify-content:flex-end;font-size:var(--fs-xs);margin-bottom:2px"><span style="font-weight:700;color:${color}">${pct}%</span></div><div class="prog-bar"><div class="prog-fill" style="width:${pct}%;background:${color}"></div></div></div>
      <span>${pct===100?'<span class="badge badge-green">OK</span>':pct>=70?'<span class="badge badge-orange">Atenção</span>':'<span class="badge badge-red">Crítico</span>'}</span>
    </div>`;
  }).join('');

  const alerts=[
    {icon:'🔴',text:'CQ 033 — Estufa Fabbe: Vigência <strong>VENCIDA</strong>',type:'danger'},
    {icon:'🟡',text:'CQ 008 — pHmetro Q400AS: Vence em <strong>3 meses</strong>',type:'warn'},
    {icon:'🟠',text:'CQ 039 — Resultado OOS: Aguardando elaboração',type:'warn'},
    {icon:'🔵',text:'5 treinamentos com assinatura pendente (AL/CQ)',type:'info'},
    {icon:'🟢',text:'DE — Des. Embalagem: <strong>100% em conformidade</strong>',type:'ok'},
  ];
  document.getElementById('alerts-list').innerHTML=alerts.map(a=>`
    <div class="alert-item ${a.type}" onclick="showAlertasModal()">
      <span class="alert-item-icon">${a.icon}</span>
      <span class="alert-item-text">${a.text}</span>
    </div>
  `).join('');

  if(chartsInit.train){chartsInit.train.destroy();chartsInit.status.destroy();}
  const tc=tvMode?'#d0d0ce':'#6b6b68';
  const gc=tvMode?'rgba(255,255,255,0.08)':'rgba(0,0,0,0.06)';

  chartsInit.train=new Chart(document.getElementById('trainChart'),{
    type:'bar',
    data:{labels:Object.values(SECTORS_DATA).map(s=>s.name),datasets:[
      {label:'Aprovados',data:Object.values(SECTORS_DATA).map(s=>s.approved),backgroundColor:'rgba(18,84,77,0.85)',borderRadius:6},
      {label:'Em Revisão/Crítico',data:Object.values(SECTORS_DATA).map(s=>s.inReview+s.expired),backgroundColor:'rgba(219,102,69,0.85)',borderRadius:6},
    ]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'top',labels:{color:tc,font:{size:11},usePointStyle:true}}},scales:{x:{stacked:true,ticks:{color:tc},grid:{color:gc}},y:{stacked:true,beginAtZero:true,ticks:{color:tc},grid:{color:gc}}}}
  });

  const approvedCount=POPS.filter(p=>p.docStatus==='APROVADO').length;
  const inReviewCount=POPS.filter(p=>p.docStatus==='EM REVISÃO').length;
  const expiredCount=POPS.filter(p=>p.vigencia==='VENCIDO').length;
  const elaborarCount=POPS.filter(p=>p.docStatus==='ELABORAR').length;
  const obsoleteCount=POPS.filter(p=>p.docStatus==='OBSOLETO').length;

  chartsInit.status=new Chart(document.getElementById('statusChart'),{
    type:'doughnut',
    data:{labels:['Aprovado','Em Revisão','Vencido','Elaborar','Obsoleto'],datasets:[{data:[approvedCount,inReviewCount,expiredCount,elaborarCount,obsoleteCount],backgroundColor:['#12544d','#db6645','#a1213d','#c4956a','#6b6b68'],borderWidth:tvMode?2:0,borderColor:tvMode?'#1e1e1c':'transparent',hoverOffset:8}]},
    options:{responsive:true,maintainAspectRatio:false,cutout:'70%',plugins:{legend:{position:'right',labels:{color:tc,font:{size:11},usePointStyle:true}}}}
  });
  document.getElementById('donut-pct-dash').textContent=compliance+'%';
}

function showAlertasModal(){navigate('alertas');}
function showPendenciasModal(){
  const pendPOPs=POPS.filter(p=>p.training==='SOLICITADO');
  const expiringP=POPS.filter(p=>p.vigencia==='VENCE EM 3 MESES');
  openModal('Detalhamento de <span>Pendências</span>',`
    <table style="width:100%;border-collapse:collapse;font-size:var(--fs-sm)">
      <thead><tr style="border-bottom:1.5px solid var(--border)">
        <th style="padding:8px;text-align:left;font-size:var(--fs-xs);color:var(--gray-soft);text-transform:uppercase">Funcionário</th>
        <th style="padding:8px;text-align:left;font-size:var(--fs-xs);color:var(--gray-soft);text-transform:uppercase">Área</th>
        <th style="padding:8px;text-align:left;font-size:var(--fs-xs);color:var(--gray-soft);text-transform:uppercase">POPs Pendentes</th>
      </tr></thead>
      <tbody>
        ${EMPLOYEES.filter(e=>e.pops.some(p=>p.status==='Pendente'||p.status==='Crítico'||p.status==='Vencido')).map(e=>{
          const pend=e.pops.filter(p=>p.status!=='Válido');
          return`<tr style="border-bottom:1px solid var(--border)">
            <td style="padding:10px 8px"><strong>${e.name}</strong><div style="font-size:var(--fs-xs);color:var(--gray-soft)">${e.role}</div></td>
            <td style="padding:10px 8px"><span class="badge badge-blue">${e.sector}</span></td>
            <td style="padding:10px 8px">${pend.map(p=>`${empStatusBadge(p.status)} <span style="font-size:var(--fs-xs)">${p.pop}</span>`).join('<br>')}</td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>
  `);
}

/* ══════════════════════════════════════════
   ANALYTICS
══════════════════════════════════════════ */
function renderAnalytics(){
  const sectors=[...new Set(POPS.map(p=>p.sector))];
  const sectorNames={AL:'Almoxarifado',CQ:'Qualidade',DE:'Des. Embalagem',DP:'P&D'};
  document.getElementById('filter-bar').innerHTML=[
    `<div class="filter-pill ${!currentSectorFilter?'active':''}" onclick="setFilter(null)">Todos</div>`,
    ...sectors.map(s=>`<div class="filter-pill ${currentSectorFilter===s?'active':''}" onclick="setFilter('${s}')">${sectorNames[s]||s}</div>`)
  ].join('');

  const fp=currentSectorFilter?POPS.filter(p=>p.sector===currentSectorFilter):POPS;
  const sName=currentSectorFilter?(sectorNames[currentSectorFilter]||currentSectorFilter):'Todos os Setores';
  document.getElementById('analytics-subtitle').textContent=`Indicadores avançados · ${sName}`;
  document.getElementById('filter-label').textContent=currentSectorFilter?`· ${sName}`:'';
  document.getElementById('clear-filter-btn').style.display=currentSectorFilter?'':'none';

  const total=fp.length;
  const approved=fp.filter(p=>p.docStatus==='APROVADO').length;
  const inReview=fp.filter(p=>p.docStatus==='EM REVISÃO').length;
  const expired=fp.filter(p=>p.vigencia==='VENCIDO').length;
  const pendTrain=fp.filter(p=>p.training==='SOLICITADO').length;

  document.getElementById('analytics-kpis').innerHTML=`
    <div class="kpi-card green glass-card"><div class="kpi-val">${total}</div><div class="kpi-label">POPs no Filtro</div></div>
    <div class="kpi-card glass-card"><div class="kpi-val">${total?Math.round(approved/total*100):0}%</div><div class="kpi-label">Taxa de Aprovação</div></div>
    <div class="kpi-card orange glass-card"><div class="kpi-val">${inReview}</div><div class="kpi-label">Em Revisão</div></div>
    <div class="kpi-card ${expired>0?'':'green'} glass-card"><div class="kpi-val">${expired+pendTrain}</div><div class="kpi-label">Vencidos + Trein. Pend.</div></div>
  `;

  document.getElementById('pops-analytics-body').innerHTML=fp.map(p=>`
    <tr>
      <td><strong style="color:var(--red)">${p.code}</strong></td>
      <td style="max-width:260px">${p.desc}</td>
      <td>${popTypeBadge(p.popType)} <span class="badge badge-blue">${p.sectorName}</span></td>
      <td>${docBadge(p.docStatus)}</td>
      <td>${vigenciaBadge(p.vigencia)}</td>
      <td>${trainBadge(p.training)}</td>
      <td><button class="btn btn-danger btn-sm" onclick="deletePOP('${p.code}')">Excluir</button></td>
    </tr>
  `).join('');

  if(chartsInit.trend){chartsInit.trend.destroy();chartsInit.doughnut.destroy();}
  const tc=tvMode?'#d0d0ce':'#6b6b68';
  const gc=tvMode?'rgba(255,255,255,0.08)':'rgba(0,0,0,0.06)';

  // Feature 4: Historical compliance trend by month
  const trendData = getHistoricalTrend();
  chartsInit.trend=new Chart(document.getElementById('trendChart'),{
    type:'line',
    data:{labels:trendData.map(t=>t.label),datasets:[{
      label:'Compliance (%)',
      data:trendData.map(t=>t.value),
      borderColor:'#12544d',
      backgroundColor:'rgba(18,84,77,.12)',
      fill:true,
      tension:.4,
      pointBackgroundColor:'#12544d',
      pointRadius:5,
      pointHoverRadius:7,
    }]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>`${ctx.parsed.y}% compliance`}}},scales:{y:{beginAtZero:false,min:30,max:100,ticks:{color:tc,callback:v=>v+'%'},grid:{color:gc}},x:{ticks:{color:tc},grid:{color:gc}}}}
  });

  const statusData=['APROVADO','EM REVISÃO','ELABORAR','OBSOLETO'].map(s=>fp.filter(p=>p.docStatus===s).length);
  const approvedPct=total?Math.round(approved/total*100):0;
  chartsInit.doughnut=new Chart(document.getElementById('donutChart'),{
    type:'doughnut',
    data:{labels:['Aprovado','Em Revisão','Elaborar','Obsoleto'],datasets:[{data:statusData,backgroundColor:['#12544d','#db6645','#c4956a','#6b6b68'],borderWidth:tvMode?2:0,borderColor:tvMode?'#1e1e1c':'transparent',hoverOffset:8}]},
    options:{responsive:true,maintainAspectRatio:false,cutout:'68%',plugins:{legend:{position:'bottom',labels:{color:tc,font:{size:11},usePointStyle:true}}}}
  });
  document.getElementById('donut-pct-anl').textContent=approvedPct+'%';
}
function setFilter(s){currentSectorFilter=s;renderAnalytics();}
function clearFilter(){setFilter(null);}

/* ══════════════════════════════════════════
   POPs LIST
══════════════════════════════════════════ */
function renderPOPs(){
  const search=(document.getElementById('pop-search')?.value||'').toLowerCase();
  const secFilter=document.getElementById('pops-sector-filter')?.value||'';
  const statFilter=document.getElementById('pops-status-filter')?.value||'';
  const vigFilter=document.getElementById('pops-vigencia-filter')?.value||'';
  let items=POPS;
  if(secFilter)items=items.filter(p=>p.sector===secFilter);
  if(statFilter)items=items.filter(p=>p.docStatus===statFilter);
  if(vigFilter)items=items.filter(p=>p.vigencia===vigFilter);
  if(search)items=items.filter(p=>p.desc.toLowerCase().includes(search)||p.code.toLowerCase().includes(search)||p.sectorName.toLowerCase().includes(search));

  document.getElementById('pops-body').innerHTML=items.map(p=>`
    <tr>
      <td><strong style="color:var(--red);cursor:pointer" onclick="openPOPDetail('${p.code}')">${p.code}</strong></td>
      <td>${popTypeBadge(p.popType)}</td>
      <td><span class="badge badge-gray">${p.sectorName}</span></td>
      <td style="max-width:220px;font-size:var(--fs-sm)">${p.desc}</td>
      <td>${docBadge(p.docStatus)}</td>
      <td style="font-size:var(--fs-xs);color:var(--gray-soft)">${p.dataCriacao||'—'}</td>
      <td style="font-size:var(--fs-xs);color:var(--gray-soft)">${p.dataRevisao||'—'}</td>
      <td style="font-size:var(--fs-xs);font-weight:700;color:${p.dataVencimento?'var(--green)':'var(--gray-soft)'}">${p.dataVencimento||'—'}</td>
      <td>${vigenciaBadge(p.vigencia)}</td>
      <td>${daysBadge(p)}</td>
      <td>${trainBadge(p.training)}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-outline btn-sm" onclick="openEditPOP('${p.code}')" style="margin-right:4px">Editar</button>
        <button class="btn btn-danger btn-sm" onclick="deletePOP('${p.code}')">Excluir</button>
      </td>
    </tr>
  `).join('');
}

function deletePOP(code){
  const pop=POPS.find(p=>p.code===code);
  if(!pop)return;
  showConfirm('Excluir POP',`Tem certeza que deseja excluir o POP "${code} — ${pop.desc}"? Esta ação não pode ser desfeita.`,()=>{
    POPS=POPS.filter(p=>p.code!==code);
    addLog(`POP Excluído: ${code}`, 'delete', `${pop.desc} · Setor: ${pop.sectorName}`);
    saveData();
    toast('POP Excluído', `${code} removido com sucesso.`, 'warn');
    renderPOPs();
    const activePage=document.querySelector('.page.active');
    if(activePage&&activePage.id==='page-analytics')renderAnalytics();
  });
}

function openEditPOP(code){
  const pop=POPS.find(p=>p.code===code);
  if(!pop)return;
  openModal(`Editar <span>${code}</span>`,`
    <div class="form-grid">
      <div class="form-group"><label class="form-label">Tipo</label>
        <select class="form-select" id="ep-type">
          <option value="core" ${pop.popType==='core'?'selected':''}>Core — Obrigatório</option>
          <option value="area" ${pop.popType==='area'?'selected':''}>Área — Setor Específico</option>
          <option value="cargo" ${pop.popType==='cargo'?'selected':''}>Cargo — Função Específica</option>
        </select>
      </div>
      <div class="form-group"><label class="form-label">Status Doc</label>
        <select class="form-select" id="ep-status">
          <option value="ELABORAR" ${pop.docStatus==='ELABORAR'?'selected':''}>Elaborar</option>
          <option value="EM REVISÃO" ${pop.docStatus==='EM REVISÃO'?'selected':''}>Em Revisão</option>
          <option value="APROVADO" ${pop.docStatus==='APROVADO'?'selected':''}>Aprovado</option>
          <option value="OBSOLETO" ${pop.docStatus==='OBSOLETO'?'selected':''}>Obsoleto</option>
        </select>
      </div>
      <div class="form-group"><label class="form-label">Vigência</label>
        <select class="form-select" id="ep-vigencia">
          <option value="NO PRAZO" ${pop.vigencia==='NO PRAZO'?'selected':''}>No Prazo</option>
          <option value="VENCE EM 3 MESES" ${pop.vigencia==='VENCE EM 3 MESES'?'selected':''}>Vence em 3 Meses</option>
          <option value="VENCIDO" ${pop.vigencia==='VENCIDO'?'selected':''}>Vencido</option>
          <option value="OBSOLETO" ${pop.vigencia==='OBSOLETO'?'selected':''}>Obsoleto</option>
          <option value="ELABORAR" ${pop.vigencia==='ELABORAR'?'selected':''}>Elaborar</option>
        </select>
      </div>
      <div class="form-group"><label class="form-label">Treinamento</label>
        <select class="form-select" id="ep-training">
          <option value="OK" ${pop.training==='OK'?'selected':''}>OK</option>
          <option value="SOLICITADO" ${pop.training==='SOLICITADO'?'selected':''}>Solicitado</option>
          <option value="N.A" ${pop.training==='N.A'?'selected':''}>N/A</option>
        </select>
      </div>
    </div>
    <div class="form-group"><label class="form-label">Descrição</label><input type="text" class="form-input" id="ep-desc" value="${pop.desc}"></div>
    <div class="form-grid">
      <div class="form-group"><label class="form-label">Data de Criação</label><input type="date" class="form-input" id="ep-criacao" value="${brToIso(pop.dataCriacao)}"></div>
      <div class="form-group"><label class="form-label">Data de Revisão</label><input type="date" class="form-input" id="ep-revisao" value="${brToIso(pop.dataRevisao)}"></div>
    </div>
    ${tagsEditor(pop)}
    ${anexosEditor(pop)}
    <div style="display:flex;gap:10px;margin-top:8px">
      <button class="btn btn-primary" onclick="salvarEditPOP('${code}')">Salvar Alterações</button>
      <button class="btn btn-danger" onclick="closeModal();deletePOP('${code}')">Excluir POP</button>
      <button class="btn btn-outline" onclick="closeModal()">Cancelar</button>
    </div>
  `);
}

function salvarEditPOP(code){
  const pop=POPS.find(p=>p.code===code);
  if(!pop)return;
  pop.popType=document.getElementById('ep-type').value;
  pop.docStatus=document.getElementById('ep-status').value;
  pop.vigencia=document.getElementById('ep-vigencia').value;
  pop.training=document.getElementById('ep-training').value;
  pop.desc=document.getElementById('ep-desc').value;
  const criacaoRaw=document.getElementById('ep-criacao').value;
  const revisaoRaw=document.getElementById('ep-revisao').value;
  pop.dataCriacao=criacaoRaw?isoToBr(criacaoRaw):'';
  pop.dataRevisao=revisaoRaw?isoToBr(revisaoRaw):'';
  // Salvar estado do anexo
  const hasAnexo=document.getElementById('ep-has-anexo')?.value;
  if(hasAnexo==='sim'){
    const sel=document.getElementById('ep-anexo-select');
    const fileInput=document.getElementById('ep-anexo-file');
    if(sel&&sel.value){pop.anexoRef=sel.value;pop.hasAnexo=true;}
    else if(fileInput&&fileInput.files&&fileInput.files[0]){
      pop.anexoFile=fileInput.files[0].name;pop.hasAnexo=true;pop.anexoRef='';
    }
  } else if(hasAnexo==='nao'){
    pop.hasAnexo=false;pop.anexoRef='';pop.anexoFile='';
  }
  addLog(`POP Editado: ${code}`, 'edit', `${pop.desc} · Status: ${pop.docStatus}`);
  saveData();
  toast('POP Atualizado', `${code} salvo com sucesso.`, 'success');
  closeModal();
  renderPOPs();
}

function getAreaOptionsForSector(selectedSector){
  const all=Object.entries(ALL_SECTORS);
  return all.filter(([k])=>k!==selectedSector).map(([k,v])=>`<option value="${k}">${v}</option>`).join('');
}

function getRolesForSelectedSectors(){
  const setor=document.getElementById('new-pop-sector')?.value||'';
  const areaEl=document.getElementById('new-pop-area');
  const selectedAreas=areaEl?[...areaEl.selectedOptions].map(o=>o.value):[];
  const allSelected=[setor,...selectedAreas].filter(Boolean);
  const sectorNames=allSelected.map(k=>ALL_SECTORS[k]||k);
  const roles=new Set();
  sectorNames.forEach(sn=>{
    (ROLES_BY_SECTOR[sn]||[]).forEach(r=>roles.add(r));
  });
  // Also check TRAINING_MATRIX for roles in those sectors
  TRAINING_MATRIX.forEach(tm=>{
    if(sectorNames.some(sn=>sn.toLowerCase().includes(tm.sector.toLowerCase())||tm.sector.toLowerCase().includes(sn.toLowerCase())))
      roles.add(tm.role.charAt(0)+tm.role.slice(1).toLowerCase());
  });
  return [...roles];
}

function updateCargoOptions(selectId){
  const roles=getRolesForSelectedSectors();
  const sel=document.getElementById(selectId);
  if(!sel)return;
  const cur=sel.value;
  sel.innerHTML='<option value="">— Selecione o cargo —</option>'+roles.map(r=>`<option value="${r}"${r===cur?' selected':''}>${r}</option>`).join('');
}

function updateAreaOptions(areaSelectId, sectorSelectId){
  const sector=document.getElementById(sectorSelectId)?.value||'';
  const areaEl=document.getElementById(areaSelectId);
  if(!areaEl)return;
  const prevSelected=[...areaEl.selectedOptions].map(o=>o.value);
  areaEl.innerHTML=getAreaOptionsForSector(sector);
  // restore previous selections if still available
  [...areaEl.options].forEach(o=>{ if(prevSelected.includes(o.value))o.selected=true; });
}

function openNovoPOP(){
  const hoje = new Date().toISOString().slice(0,10);
  const sectorOpts=Object.entries(ALL_SECTORS).map(([k,v])=>`<option value="${k}">${v}</option>`).join('');
  const areaOpts=Object.entries(ALL_SECTORS).filter(([k])=>k!=='AL').map(([k,v])=>`<option value="${k}">${v}</option>`).join('');
  openModal('+ Novo <span>POP</span>',`
    <div class="form-grid">
      <div class="form-group"><label class="form-label">Código</label><input type="text" class="form-input" placeholder="Ex: CQ 041" id="new-pop-code"></div>
      <div class="form-group"><label class="form-label">Setor</label>
        <select class="form-select" id="new-pop-sector" onchange="updateAreaOptions('new-pop-area','new-pop-sector');updateCargoOptions('new-pop-cargo')">${sectorOpts}</select>
      </div>
      <div class="form-group"><label class="form-label">Área <span style="font-size:.7rem;color:var(--gray-soft)">(multi-seleção)</span></label>
        <select class="form-select" id="new-pop-area" multiple style="min-height:80px;height:auto" onchange="updateCargoOptions('new-pop-cargo')">${areaOpts}</select>
      </div>
      <div class="form-group"><label class="form-label">Cargo</label>
        <select class="form-select" id="new-pop-cargo"><option value="">— Selecione o cargo —</option></select>
      </div>
      <div class="form-group"><label class="form-label">Status Doc</label>
        <select class="form-select" id="new-pop-status"><option value="ELABORAR">Elaborar</option><option value="EM REVISÃO">Em Revisão</option><option value="APROVADO">Aprovado</option><option value="OBSOLETO">Obsoleto</option></select>
      </div>
    </div>
    <div class="form-group"><label class="form-label">Descrição</label><input type="text" class="form-input" placeholder="Descrição do procedimento" id="new-pop-desc"></div>
    <div class="form-grid">
      <div class="form-group">
        <label class="form-label">Data de Criação</label>
        <input type="date" class="form-input" id="new-pop-datacriacao" value="${hoje}" oninput="atualizarVencimentoPOP()">
      </div>
      <div class="form-group">
        <label class="form-label">Vencimento (5 anos)</label>
        <input type="text" class="form-input" id="new-pop-vencimento" readonly style="background:var(--gray-pale);cursor:not-allowed;font-weight:700;color:var(--green)">
      </div>
    </div>
    <div id="new-pop-venc-preview" style="padding:10px 14px;background:var(--green-bg);border-radius:var(--r);border-left:3px solid var(--green);font-size:var(--fs-sm);margin-bottom:14px">
      Vencimento em <strong id="new-pop-venc-label"></strong> · <span id="new-pop-dias-label" style="font-weight:700"></span>
    </div>
    ${anexosEditorNew()}
    <button class="btn btn-primary" onclick="salvarNovoPOP()">Salvar POP</button>
  `);
  atualizarVencimentoPOP();
  updateCargoOptions('new-pop-cargo');
}

function atualizarVencimentoPOP(){
  const raw = document.getElementById('new-pop-datacriacao')?.value;
  const vencEl = document.getElementById('new-pop-vencimento');
  const labelEl = document.getElementById('new-pop-venc-label');
  const diasEl = document.getElementById('new-pop-dias-label');
  const previewEl = document.getElementById('new-pop-venc-preview');
  if(!raw || !vencEl) return;
  const d = new Date(raw + 'T00:00:00');
  const venc = new Date(d);
  venc.setFullYear(venc.getFullYear() + 5);
  const vencStr = venc.toLocaleDateString('pt-BR');
  vencEl.value = vencStr;
  if(labelEl) labelEl.textContent = vencStr;
  const dias = Math.ceil((venc - new Date()) / 86400000);
  if(diasEl){
    if(dias < 0){ diasEl.textContent = `Vencido há ${Math.abs(dias)} dias`; diasEl.style.color='var(--red)'; }
    else if(dias <= 90){ diasEl.textContent = `⚠ ${dias} dias restantes`; diasEl.style.color='var(--orange)'; }
    else { diasEl.textContent = `✓ ${dias} dias restantes`; diasEl.style.color='var(--green)'; }
  }
  if(previewEl) previewEl.style.display = '';
}

function salvarNovoPOP(){
  const sectorMap={AL:'Almoxarifado',CQ:'Qualidade',DE:'Des. Embalagem',DP:'P&D'};
  const sector=document.getElementById('new-pop-sector').value;
  const code=document.getElementById('new-pop-code').value.trim()||'N/A';
  const desc=document.getElementById('new-pop-desc').value.trim()||'Sem descrição';
  if(!code||code==='N/A'){toast('Código obrigatório','Informe um código para o POP.','error');return;}
  const rawDate = document.getElementById('new-pop-datacriacao')?.value;
  let dataCriacao, dataVencimento;
  if(rawDate){
    const d = new Date(rawDate+'T00:00:00');
    dataCriacao = d.toLocaleDateString('pt-BR');
    const venc = new Date(d); venc.setFullYear(venc.getFullYear()+5);
    dataVencimento = venc.toLocaleDateString('pt-BR');
  } else {
    dataCriacao = new Date().toLocaleDateString('pt-BR');
    const venc = new Date(); venc.setFullYear(venc.getFullYear()+5);
    dataVencimento = venc.toLocaleDateString('pt-BR');
  }
  POPS.push({code,type:'POP',popType:document.getElementById('new-pop-type').value,sector,sectorName:sectorMap[sector]||sector,desc,docStatus:document.getElementById('new-pop-status').value,vigencia:'NO PRAZO',training:'N.A',dataCriacao,dataVencimento,...getAnexoFromNew()});
  addLog(`POP Criado: ${code}`, 'create', `${desc} · Setor: ${sectorMap[sector]||sector} · Venc: ${dataVencimento}`);
  saveData();
  toast('POP Criado', `${code} adicionado. Vencimento: ${dataVencimento}.`, 'success');
  closeModal();renderPOPs();
}

function openPOPDetail(code){
  const pop=POPS.find(p=>p.code===code);
  if(!pop)return;
  openModal(`POP — <span>${code}</span>`,`
    <div style="padding:14px;background:var(--red-pale);border-radius:var(--r);margin-bottom:16px;border-left:3px solid var(--red)">
      <div style="font-weight:700;font-size:var(--fs-base);color:var(--gray);margin-bottom:6px">${pop.desc}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">${docBadge(pop.docStatus)} ${vigenciaBadge(pop.vigencia)}</div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
      <button class="btn btn-primary" onclick="closeModal();setTimeout(()=>openPOPAnexos('${code}'),100)" style="padding:16px;flex-direction:column;gap:4px">Ver Anexos</button>
      <button class="btn btn-outline" onclick="closeModal();setTimeout(()=>openPOPEmployees('${code}'),100)" style="padding:16px;flex-direction:column;gap:4px">Ver Funcionários</button>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn btn-outline btn-sm" onclick="closeModal();setTimeout(()=>openRevisao('${code}'),100)">Revisar</button>
    </div>
  `);
}













/* ══════════════════════════════════════════
   LOCALSTORAGE PERSISTENCE
══════════════════════════════════════════ */
const LS_KEY_POPS = 'nazca_pops_v2';
const LS_KEY_ANEXOS = 'nazca_anexos_v2';
const LS_KEY_LOGS = 'nazca_logs_v2';

function saveData() {
  try {
    localStorage.setItem(LS_KEY_POPS, JSON.stringify(POPS));
    localStorage.setItem(LS_KEY_ANEXOS, JSON.stringify(ANEXOS));
    localStorage.setItem(LS_KEY_LOGS, JSON.stringify(LOGS.slice(-200))); // keep last 200 logs
  } catch(e) { console.warn('LocalStorage save error:', e); }
}















/* ══════════════════════════════════════════
   FEATURE 3: KANBAN VIEW FOR POPs
══════════════════════════════════════════ */
let _popsView = 'table';

function setPOPsView(v) {
  _popsView = v;
  document.getElementById('view-table-btn').classList.toggle('active', v === 'table');
  document.getElementById('view-kanban-btn').classList.toggle('active', v === 'kanban');
  document.getElementById('pops-table-view').style.display = v === 'table' ? '' : 'none';
  document.getElementById('pops-kanban-view').style.display = v === 'kanban' ? '' : 'none';
  renderPOPs();
}

function renderKanban(items) {
  const statuses = [
    {key:'APROVADO', label:'✅ Aprovado', color:'var(--green)'},
    {key:'EM REVISÃO', label:'🔄 Em Revisão', color:'var(--orange)'},
    {key:'ELABORAR', label:'📝 Elaborar', color:'var(--sand-dark)'},
    {key:'OBSOLETO', label:'🗄 Obsoleto', color:'var(--gray-soft)'},
  ];
  const board = document.getElementById('pops-kanban-board');
  if (!board) return;
  board.innerHTML = statuses.map(st => {
    const cards = items.filter(p => p.docStatus === st.key);
    return `<div class="kanban-col">
      <div class="kanban-col-header">
        <div class="kanban-col-title" style="color:${st.color}">${st.label}</div>
        <span class="kanban-col-count">${cards.length}</span>
      </div>
      ${cards.map(p => `
        <div class="kanban-card" onclick="openPOPDetail('${p.code}')">
          <div class="kanban-card-code">${p.code}</div>
          <div class="kanban-card-desc">${p.desc.substring(0, 65)}${p.desc.length > 65 ? '…' : ''}</div>
          <div class="kanban-card-footer">
            ${popTypeBadge(p.popType)}
            ${vigenciaBadge(p.vigencia)}
            ${daysBadge(p)}
            ${(p.tags || []).map(t => `<span class="tag-chip">#${t}</span>`).join('')}
          </div>
        </div>
      `).join('')}
      ${!cards.length ? '<div style="text-align:center;padding:20px;font-size:.8rem;color:var(--gray-soft)">Nenhum POP</div>' : ''}
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════════
   FEATURE 4: HISTORICAL COMPLIANCE TREND
══════════════════════════════════════════ */
function getHistoricalTrend() {
  const now = new Date();
  const months = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({ label: d.toLocaleDateString('pt-BR', {month:'short', year:'2-digit'}), d });
  }
  // Simulate compliance trend: base on current + small random variation seeded by month
  const approved = POPS.filter(p => p.docStatus === 'APROVADO').length;
  const total = POPS.length;
  const base = total ? Math.round(approved / total * 100) : 75;
  return months.map((m, i) => {
    // pseudo-deterministic variation
    const seed = (m.d.getMonth() * 7 + m.d.getFullYear()) % 10;
    const variation = (seed - 5) * 1.2;
    return { label: m.label, value: Math.max(40, Math.min(100, Math.round(base - (5 - i) * 2 + variation))) };
  });
}





/* ══════════════════════════════════════════
   ANEXOS HELPERS
══════════════════════════════════════════ */
// Simulated DB of existing attachments
const ANEXOS_DB=[
  {id:'ANX001',name:'IT-AL-001 Instrução de Trabalho.pdf'},
  {id:'ANX002',name:'POP-CQ-Controle Qualidade Rev3.pdf'},
  {id:'ANX003',name:'Fluxograma Recebimento MP v2.pdf'},
  {id:'ANX004',name:'Checklist Auditoria Interna 2025.pdf'},
  {id:'ANX005',name:'Procedimento de Calibração EPI.pdf'},
];

function anexosEditorNew(){
  const opts=ANEXOS_DB.map(a=>`<option value="${a.id}">${a.name}</option>`).join('');
  return `
  <div class="form-group" style="margin-bottom:14px">
    <label class="form-label">📎 Este POP possui anexo?</label>
    <div style="display:flex;gap:10px;margin-top:6px">
      <button type="button" class="btn btn-outline btn-sm" id="new-anexo-sim" onclick="toggleAnexoNew('sim')" style="border-color:var(--border)">✅ Sim</button>
      <button type="button" class="btn btn-outline btn-sm" id="new-anexo-nao" onclick="toggleAnexoNew('nao')" style="background:var(--gray-pale)">❌ Não</button>
    </div>
    <input type="hidden" id="new-has-anexo" value="">
    <div id="new-anexo-content" style="display:none;margin-top:12px;padding:14px;background:var(--blue-bg);border-radius:var(--r);border-left:3px solid var(--blue)">
      <div style="font-size:var(--fs-sm);font-weight:700;margin-bottom:10px;color:var(--blue)">Selecione o tipo de anexo:</div>
      <div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap">
        <button type="button" class="btn btn-outline btn-sm" id="new-anexo-db-btn" onclick="toggleAnexoType('new','db')">📂 Selecionar do Sistema</button>
        <button type="button" class="btn btn-outline btn-sm" id="new-anexo-upload-btn" onclick="toggleAnexoType('new','upload')">⬆️ Fazer Upload PDF</button>
      </div>
      <div id="new-anexo-db" style="display:none">
        <label class="form-label">Anexos disponíveis no sistema:</label>
        <select class="form-select" id="new-anexo-select">
          <option value="">— Selecione um arquivo —</option>
          ${opts}
        </select>
      </div>
      <div id="new-anexo-upload" style="display:none">
        <label class="form-label">Selecionar arquivo PDF:</label>
        <input type="file" accept=".pdf" class="form-input" id="new-anexo-file" style="padding:8px;cursor:pointer">
        <div style="font-size:var(--fs-xs);color:var(--gray-soft);margin-top:4px">Apenas arquivos PDF são aceitos</div>
      </div>
    </div>
  </div>`;
}

function anexosEditor(pop){
  const hasA=pop.hasAnexo;
  const opts=ANEXOS_DB.map(a=>`<option value="${a.id}" ${pop.anexoRef===a.id?'selected':''}>${a.name}</option>`).join('');
  const currentLabel=hasA?(pop.anexoRef?ANEXOS_DB.find(a=>a.id===pop.anexoRef)?.name||pop.anexoRef:pop.anexoFile||'Arquivo local'):'';
  return `
  <div class="form-group" style="margin-bottom:14px">
    <label class="form-label">📎 Este POP possui anexo?</label>
    ${hasA?`<div style="margin-top:4px;font-size:var(--fs-xs);color:var(--green);font-weight:600">✅ Atual: ${currentLabel}</div>`:''}
    <div style="display:flex;gap:10px;margin-top:8px">
      <button type="button" class="btn btn-sm ${hasA?'btn-primary':'btn-outline'}" id="ep-anexo-sim" onclick="toggleAnexoEp('sim')" style="${hasA?'':'border-color:var(--border)'}">✅ Sim</button>
      <button type="button" class="btn btn-sm ${!hasA?'btn-primary':'btn-outline'}" id="ep-anexo-nao" onclick="toggleAnexoEp('nao')" style="${!hasA?'':'background:var(--gray-pale)'}">❌ Não</button>
    </div>
    <input type="hidden" id="ep-has-anexo" value="${hasA?'sim':'nao'}">
    <div id="ep-anexo-content" style="display:${hasA?'block':'none'};margin-top:12px;padding:14px;background:var(--blue-bg);border-radius:var(--r);border-left:3px solid var(--blue)">
      <div style="font-size:var(--fs-sm);font-weight:700;margin-bottom:10px;color:var(--blue)">Selecione o tipo de anexo:</div>
      <div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap">
        <button type="button" class="btn btn-outline btn-sm" id="ep-anexo-db-btn" onclick="toggleAnexoType('ep','db')">📂 Selecionar do Sistema</button>
        <button type="button" class="btn btn-outline btn-sm" id="ep-anexo-upload-btn" onclick="toggleAnexoType('ep','upload')">⬆️ Fazer Upload PDF</button>
      </div>
      <div id="ep-anexo-db" style="display:${pop.anexoRef?'block':'none'}">
        <label class="form-label">Anexos disponíveis no sistema:</label>
        <select class="form-select" id="ep-anexo-select">
          <option value="">— Selecione um arquivo —</option>
          ${opts}
        </select>
      </div>
      <div id="ep-anexo-upload" style="display:${pop.anexoFile&&!pop.anexoRef?'block':'none'}">
        <label class="form-label">Selecionar arquivo PDF:</label>
        <input type="file" accept=".pdf" class="form-input" id="ep-anexo-file" style="padding:8px;cursor:pointer">
        <div style="font-size:var(--fs-xs);color:var(--gray-soft);margin-top:4px">Apenas arquivos PDF são aceitos</div>
      </div>
    </div>
  </div>`;
}

function toggleAnexoNew(val){
  document.getElementById('new-has-anexo').value=val;
  const content=document.getElementById('new-anexo-content');
  content.style.display=val==='sim'?'block':'none';
  document.getElementById('new-anexo-sim').className='btn btn-sm '+(val==='sim'?'btn-primary':'btn-outline');
  document.getElementById('new-anexo-nao').className='btn btn-sm '+(val==='nao'?'btn-primary':'btn-outline');
}

function toggleAnexoEp(val){
  document.getElementById('ep-has-anexo').value=val;
  const content=document.getElementById('ep-anexo-content');
  content.style.display=val==='sim'?'block':'none';
  document.getElementById('ep-anexo-sim').className='btn btn-sm '+(val==='sim'?'btn-primary':'btn-outline');
  document.getElementById('ep-anexo-nao').className='btn btn-sm '+(val==='nao'?'btn-primary':'btn-outline');
}

function toggleAnexoType(prefix,type){
  document.getElementById(`${prefix}-anexo-db`).style.display=type==='db'?'block':'none';
  document.getElementById(`${prefix}-anexo-upload`).style.display=type==='upload'?'block':'none';
  document.getElementById(`${prefix}-anexo-db-btn`).className='btn btn-outline btn-sm'+(type==='db'?' btn-primary':'');
  document.getElementById(`${prefix}-anexo-upload-btn`).className='btn btn-outline btn-sm'+(type==='upload'?' btn-primary':'');
}

function getAnexoFromNew(){
  const hasAnexo=document.getElementById('new-has-anexo')?.value;
  if(hasAnexo==='sim'){
    const sel=document.getElementById('new-anexo-select');
    const fileInput=document.getElementById('new-anexo-file');
    if(sel&&sel.value) return {hasAnexo:true,anexoRef:sel.value,anexoFile:''};
    if(fileInput&&fileInput.files&&fileInput.files[0]) return {hasAnexo:true,anexoFile:fileInput.files[0].name,anexoRef:''};
    return {hasAnexo:true,anexoRef:'',anexoFile:''};
  }
  return {hasAnexo:false,anexoRef:'',anexoFile:''};
}

