/* ══════════════════════════════════════════
   MATRIX
══════════════════════════════════════════ */
function renderMatrix(){
  const table=document.getElementById('heatmap-table');
  const corePopsSet=new Set(CORE_POPS);
  const cargoPopsSet=new Set(MATRIX_POPS.filter(p=>p.startsWith('DE')));
  const popThClass=p=>{
    if(corePopsSet.has(p))return'pop-th-core';
    if(cargoPopsSet.has(p))return'pop-th-cargo';
    return'pop-th-area';
  };
  const headerCells=MATRIX_POPS.map(p=>`<th class="${popThClass(p)}" title="${POPS.find(x=>x.code===p)?.desc||''}">${p}</th>`).join('');
  table.innerHTML=`
    <thead><tr><th class="row-label">Cargo / Setor</th>${headerCells}</tr></thead>
    <tbody>${TRAINING_MATRIX.map(role=>{
      const cells=MATRIX_POPS.map(pop=>{
        const idx=role.pops.indexOf(pop);
        if(idx===-1)return`<td><div class="heat-cell heat-na" title="N/A">—</div></td>`;
        const s=role.status[idx];
        const isCore=corePopsSet.has(pop);
        if(isCore&&s==='OK')return`<td title="${pop}: Core OK"><div class="heat-cell heat-core">★</div></td>`;
        return`<td title="${pop}: ${s}"><div class="heat-cell ${s==='OK'?'heat-ok':'heat-pend'}">${s==='OK'?'✓':'⏳'}</div></td>`;
      }).join('');
      return`<tr><td class="role-name"><div style="font-size:.8rem;font-weight:700">${role.role}</div><div class="role-sector">${role.sector}</div></td>${cells}</tr>`;
    }).join('')}</tbody>
  `;
}