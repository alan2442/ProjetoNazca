/* ══════════════════════════════════════════
   FUNCIONÁRIOS
══════════════════════════════════════════ */
function renderFuncionarios(){
  const sectors=[...new Set(EMPLOYEES.map(e=>e.sector))].sort();
  const sel=document.getElementById('emp-sector-filter');
  const current=sel.value;
  sel.innerHTML='<option value="">Todos os Setores</option>'+sectors.map(s=>`<option value="${s}"${s===current?' selected':''}>${s}</option>`).join('');
  const filter=sel.value;
  const list=filter?EMPLOYEES.filter(e=>e.sector===filter):EMPLOYEES;

  document.getElementById('emp-grid').innerHTML=list.map(emp=>{
    const pct=empCompliance(emp);
    const color=pct>=80?'var(--green)':pct>=50?'var(--orange)':'var(--red)';
    const inactive=emp.inactive===true;
    if(inactive){
      return`<div class="emp-card emp-card-inactive">
        <div class="emp-card-header">
          <div>
            <div class="emp-name" style="color:var(--gray-soft);pointer-events:none">${emp.name}</div>
            <div class="emp-role" style="opacity:.5">${emp.role} · <span class="badge badge-blue" style="font-size:.65rem">${emp.sector}</span></div>
          </div>
          <div class="emp-card-actions">
            <span style="font-size:var(--fs-xs);color:var(--gray-soft);font-weight:600;padding:4px 8px;background:var(--gray-pale);border-radius:6px">Inativo</span>
            <button class="btn btn-outline btn-sm" onclick="reintegrarFuncionario(${emp.id})" title="Reintegrar" style="color:var(--green);border-color:var(--green)">Reintegrar</button>
          </div>
        </div>
        <div style="display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap;opacity:.4">
          <span style="font-size:var(--fs-xs);color:var(--gray-soft)">Core: <strong>${emp.pops.filter(p=>p.type==='core').length}</strong></span>
          <span style="font-size:var(--fs-xs);color:var(--gray-soft)">Área: <strong>${emp.pops.filter(p=>p.type==='area').length}</strong></span>
          <span style="font-size:var(--fs-xs);color:var(--gray-soft);font-weight:700">${pct}% compliant</span>
        </div>
        <div class="emp-compliance" style="opacity:.4">
          <div class="emp-compliance-bar"><div class="emp-compliance-fill" style="width:${pct}%;background:var(--gray-soft)"></div></div>
        </div>
        <div style="margin-top:8px;display:flex;gap:5px;flex-wrap:wrap;opacity:.4">
          ${emp.pops.slice(0,3).map(p=>empStatusBadge(p.status)).join('')}
          ${emp.pops.length>3?`<span class="badge badge-gray">+${emp.pops.length-3}</span>`:''}
        </div>
      </div>`;
    }
    return`<div class="emp-card">
      <div class="emp-card-header">
        <div>
          <div class="emp-name" onclick="openEmpProfile(${emp.id})">${emp.name}</div>
          <div class="emp-role">${emp.role} · <span class="badge badge-blue" style="font-size:.65rem">${emp.sector}</span></div>
        </div>
        <div class="emp-card-actions">
          <button class="btn btn-outline btn-sm" onclick="openEditFuncionario(${emp.id})" title="Modificar">Editar</button>
          <button class="btn btn-sm" onclick="inativarFuncionario(${emp.id})" title="Inativar" style="background:var(--gray-soft);color:#fff;border:none;padding:5px 10px;border-radius:var(--r);cursor:pointer;font-size:var(--fs-xs);font-weight:600">Inativar</button>
        </div>
      </div>
      <div style="display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap">
        <span style="font-size:var(--fs-xs);color:var(--gray-soft)">Core: <strong>${emp.pops.filter(p=>p.type==='core').length}</strong></span>
        <span style="font-size:var(--fs-xs);color:var(--gray-soft)">Área: <strong>${emp.pops.filter(p=>p.type==='area').length}</strong></span>
        <span style="font-size:var(--fs-xs);color:${color};font-weight:700">${pct}% compliant</span>
      </div>
      <div class="emp-compliance">
        <div class="emp-compliance-bar"><div class="emp-compliance-fill" style="width:${pct}%;background:${color}"></div></div>
      </div>
      <div style="margin-top:8px;display:flex;gap:5px;flex-wrap:wrap">
        ${emp.pops.slice(0,3).map(p=>empStatusBadge(p.status)).join('')}
        ${emp.pops.length>3?`<span class="badge badge-gray">+${emp.pops.length-3}</span>`:''}
      </div>
    </div>`;
  }).join('');
}

function openEmpProfile(id){
  const emp=EMPLOYEES.find(e=>e.id===id);
  if(!emp)return;
  const pct=empCompliance(emp);
  const color=pct>=80?'var(--green)':pct>=50?'var(--orange)':'var(--red)';
  const corePops=emp.pops.filter(p=>p.type==='core');
  const areaPops=emp.pops.filter(p=>p.type==='area');
  const cargoPops=emp.pops.filter(p=>p.type==='cargo');
  const popSection=(title,list,badge)=>list.length?`
    <div style="margin-bottom:14px">
      <div style="font-weight:700;font-size:var(--fs-sm);margin-bottom:8px;display:flex;align-items:center;gap:8px">${title} ${badge}</div>
      ${list.map(p=>`<div style="display:flex;align-items:center;justify-content:space-between;background:var(--gray-pale);padding:8px 12px;border-radius:8px;margin-bottom:4px;gap:8px;flex-wrap:wrap">
        <span style="font-size:var(--fs-sm)">${p.pop}</span>
        <div style="display:flex;align-items:center;gap:6px">
          ${p.days!=null?`<span style="font-size:var(--fs-xs);color:var(--gray-soft)">${p.days>0?p.days+'d restantes':'Vencido há '+Math.abs(p.days)+'d'}</span>`:''}
          ${empStatusBadge(p.status)}
        </div>
      </div>`).join('')}
    </div>
  `:'';

  openModal(`Perfil — <span>${emp.name.split(' ')[0]}</span>`,`
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:18px;padding:14px;background:var(--gray-pale);border-radius:var(--r);flex-wrap:wrap">
      <div style="width:48px;height:48px;border-radius:50%;background:var(--red);display:flex;align-items:center;justify-content:center;font-size:1.4rem;color:white;font-weight:800;flex-shrink:0">${emp.name.charAt(0)}</div>
      <div style="flex:1;min-width:150px">
        <div style="font-weight:700;font-size:var(--fs-md)">${emp.name}</div>
        <div style="font-size:var(--fs-sm);color:var(--gray-soft)">${emp.role} · ${emp.sector}</div>
        <div style="font-size:var(--fs-xs);color:var(--gray-soft)">Admissão: ${emp.admission} · ${emp.email}</div>
      </div>
      <div style="text-align:center">
        <div style="font-size:1.8rem;font-weight:800;color:${color}">${pct}%</div>
        <div style="font-size:var(--fs-xs);color:var(--gray-soft)">Compliance</div>
      </div>
    </div>
    ${popSection('POPs Core',corePops,'<span class="badge badge-blue">Obrigatório</span>')}
    ${popSection('POPs de Área',areaPops,'<span class="badge badge-green">Setor</span>')}
    ${popSection('POPs de Cargo',cargoPops,'<span class="badge badge-orange">Cargo</span>')}
    ${!emp.pops.length?'<div style="color:var(--gray-soft)">Nenhum POP atribuído.</div>':''}
    <div style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn btn-primary btn-sm" onclick="closeModal();setTimeout(()=>openEditFuncionario(${emp.id}),100)">Modificar</button>
      <button class="btn btn-sm" onclick="closeModal();inativarFuncionario(${emp.id})" style="background:var(--gray-soft);color:#fff;border:none;padding:6px 14px;border-radius:var(--r);cursor:pointer;font-size:var(--fs-xs);font-weight:600">Inativar</button>
    </div>
  `);
}

function openEditFuncionario(id){
  const emp=EMPLOYEES.find(e=>e.id===id);
  if(!emp)return;
  const sectors=Object.keys({...{[emp.sector]:[]}, 'Qualidade de Vida':[], 'Nutrição':[], 'Operações':[], 'Segurança do Trabalho':[], 'RH':[], 'Jurídico':[], 'Administrativo':[], 'Almoxarifado':[], 'Qualidade':[], 'Des. Embalagem':[], 'P&D':[], 'Produção':[], 'Manipulação':[], 'PCP':[] });
  openModal(`Modificar — <span>${emp.name.split(' ')[0]}</span>`,`
    <div class="form-grid">
      <div class="form-group"><label class="form-label">Nome Completo</label><input type="text" class="form-input" id="ef-name" value="${emp.name}"></div>
      <div class="form-group"><label class="form-label">E-mail</label><input type="text" class="form-input" id="ef-email" value="${emp.email}"></div>
      <div class="form-group"><label class="form-label">Setor</label>
        <select class="form-select" id="ef-sector">
          ${sectors.map(s=>`<option value="${s}" ${s===emp.sector?'selected':''}>${s}</option>`).join('')}
        </select>
      </div>
      <div class="form-group"><label class="form-label">Data de Admissão</label><input type="date" class="form-input" id="ef-admission" value="${emp.admission}"></div>
    </div>
    <div class="form-group"><label class="form-label">Cargo</label><input type="text" class="form-input" id="ef-role" value="${emp.role}"></div>
    <div style="display:flex;gap:10px;margin-top:8px;flex-wrap:wrap">
      <button class="btn btn-primary" onclick="salvarEditFuncionario(${id})">Salvar Alterações</button>
      <button class="btn btn-sm" onclick="closeModal();inativarFuncionario(${id})" style="background:var(--gray-soft);color:#fff;border:none;padding:6px 14px;border-radius:var(--r);cursor:pointer;font-size:var(--fs-xs);font-weight:600">Inativar Funcionário</button>
      <button class="btn btn-outline" onclick="closeModal()">Cancelar</button>
    </div>
  `);
}

function salvarEditFuncionario(id){
  const emp=EMPLOYEES.find(e=>e.id===id);
  if(!emp)return;
  emp.name=document.getElementById('ef-name').value.trim()||emp.name;
  emp.email=document.getElementById('ef-email').value.trim()||emp.email;
  emp.sector=document.getElementById('ef-sector').value||emp.sector;
  emp.role=document.getElementById('ef-role').value.trim()||emp.role;
  emp.admission=document.getElementById('ef-admission').value||emp.admission;
  closeModal();renderFuncionarios();
}

function deleteFuncionario(id){
  const emp=EMPLOYEES.find(e=>e.id===id);
  if(!emp)return;
  showConfirm('Excluir Funcionário',`Tem certeza que deseja excluir "${emp.name}"? Esta ação não pode ser desfeita.`,()=>{
    addLog(`Funcionário Excluído: ${emp.name}`, 'delete', `${emp.role} · ${emp.sector}`);
    EMPLOYEES=EMPLOYEES.filter(e=>e.id!==id);
    toast('Funcionário Removido', `${emp.name} excluído do sistema.`, 'warn');
    renderFuncionarios();
  });
}

function inativarFuncionario(id){
  const emp=EMPLOYEES.find(e=>e.id===id);
  if(!emp)return;
  showConfirm('Inativar Funcionário',`Deseja inativar "${emp.name}"? O registro será mantido, mas o funcionário ficará inativo e não poderá ser editado.`,()=>{
    emp.inactive=true;
    addLog(`Funcionário Inativado: ${emp.name}`, 'edit', `${emp.role} · ${emp.sector}`);
    toast('Funcionário Inativado', `${emp.name} foi inativado.`, 'warn');
    renderFuncionarios();
  });
}

function reintegrarFuncionario(id){
  const emp=EMPLOYEES.find(e=>e.id===id);
  if(!emp)return;
  emp.inactive=false;
  addLog(`Funcionário Reintegrado: ${emp.name}`, 'edit', `${emp.role} · ${emp.sector}`);
  toast('Funcionário Reintegrado', `${emp.name} foi reintegrado ao sistema.`, 'ok');
  renderFuncionarios();
}

function openNovoFuncionario(){
  openModal('+ Registrar <span>Funcionário</span>',`
    <div class="form-grid">
      <div class="form-group"><label class="form-label">Nome completo</label><input type="text" class="form-input" id="nf-name" placeholder="Nome Sobrenome"></div>
      <div class="form-group"><label class="form-label">E-mail</label><input type="text" class="form-input" id="nf-email" placeholder="email@nazca.com"></div>
      <div class="form-group"><label class="form-label">Data de Admissão</label><input type="date" class="form-input" id="nf-admission"></div>
      <div class="form-group"><label class="form-label">Setor / Área</label>
        <select class="form-select" id="nf-sector" onchange="previewOnboarding()">
          <option value="">Selecione o setor...</option>
          ${Object.keys(ONBOARDING_MAP).map(s=>`<option value="${s}">${s}</option>`).join('')}
          <option value="Outro">Outro</option>
        </select>
      </div>
      <div class="form-group" style="grid-column:span 2"><label class="form-label">Cargo</label><input type="text" class="form-input" id="nf-role" placeholder="Cargo do funcionário"></div>
    </div>
    <div id="onboarding-preview" style="margin:10px 0"></div>
    <button class="btn btn-primary" onclick="salvarNovoFuncionario()">✓ Registrar</button>
  `);
}

function previewOnboarding(){
  const sector=document.getElementById('nf-sector').value;
  const pops=ONBOARDING_MAP[sector]||[];
  const el=document.getElementById('onboarding-preview');
  if(!pops.length){el.innerHTML='';return;}
  el.innerHTML=`<div style="padding:12px;background:var(--orange-bg);border-radius:var(--r);border-left:3px solid var(--orange)">
    <div style="font-weight:700;font-size:var(--fs-sm);margin-bottom:8px">POPs de Onboarding:</div>
    ${pops.map(p=>`<div class="pending-pop-item"><span class="badge badge-orange" style="flex-shrink:0">Pendente</span><span>${p}</span></div>`).join('')}
  </div>`;
}

function salvarNovoFuncionario(){
  const name=document.getElementById('nf-name').value.trim();
  const email=document.getElementById('nf-email').value.trim();
  const sector=document.getElementById('nf-sector').value;
  const role=document.getElementById('nf-role').value.trim();
  const admission=document.getElementById('nf-admission').value;
  if(!name||!sector){toast('Campos obrigatórios','Preencha nome e setor.','error');return;}
  const pops=(ONBOARDING_MAP[sector]||[]).map(p=>({pop:p,version:'1.0',status:'Pendente',days:null,type:p.includes('LGPD')||p.includes('Higiene')?'core':'area'}));
  EMPLOYEES.push({id:nextEmpId++,name,email,sector,role,admission:admission||new Date().toISOString().slice(0,10),pops});
  addLog(`Funcionário Registrado: ${name}`, 'create', `${role} · ${sector}`);
  toast('Funcionário Registrado', `${name} adicionado com sucesso.`, 'success');
  closeModal();renderFuncionarios();
}

function openNovoTreinamento(){
  openModal('+ Novo <span>Treinamento</span>',`
    <div class="form-group"><label class="form-label">Funcionário</label>
      <select class="form-select" id="nt-emp" onchange="onNTEmpChange()">
        <option value="">Selecione o funcionário...</option>
        ${EMPLOYEES.map(e=>`<option value="${e.id}">${e.name} — ${e.sector}</option>`).join('')}
      </select>
    </div>
    <div class="form-group"><label class="form-label">Setor (automático)</label><input type="text" class="form-input" id="nt-sector" readonly placeholder="Setor será preenchido automaticamente" style="background:var(--gray-pale);cursor:not-allowed"></div>
    <div class="form-group"><label class="form-label">POP / Procedimento</label>
      <select class="form-select" id="nt-pop"><option value="">— Selecione um funcionário primeiro —</option></select>
    </div>
    <button class="btn btn-primary" onclick="closeModal()">Registrar Treinamento</button>
  `);
}

function onNTEmpChange(){
  const empId=parseInt(document.getElementById('nt-emp').value);
  const emp=EMPLOYEES.find(e=>e.id===empId);
  if(!emp)return;
  document.getElementById('nt-sector').value=emp.sector;
  const sectorCodeMap={'Almoxarifado':'AL','Qualidade':'CQ','Des. Embalagem':'DE','P&D':'DP'};
  const prefix=sectorCodeMap[emp.sector];
  const relevantPOPs=POPS.filter(p=>!prefix||p.sector===prefix||CORE_POPS.includes(p.code));
  const popSel=document.getElementById('nt-pop');
  popSel.innerHTML=relevantPOPs.map(p=>`<option value="${p.code}">${p.code} — ${p.desc}</option>`).join('');
}