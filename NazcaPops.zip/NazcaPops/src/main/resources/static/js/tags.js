/* ══════════════════════════════════════════
   FEATURE 5: TAGS SYSTEM
══════════════════════════════════════════ */
let _activeTagFilter = null;

function getAllTags() {
  const set = new Set();
  POPS.forEach(p => (p.tags || []).forEach(t => set.add(t)));
  return [...set].sort();
}

function setTagFilter(tag) {
  _activeTagFilter = tag;
  // update UI
  document.querySelectorAll('[data-tag-pill]').forEach(el => {
    el.classList.toggle('tag-filter-active', el.dataset.tagPill === (tag || '__all__'));
  });
  document.getElementById('tag-all')?.classList.toggle('tag-filter-active', !tag);
  renderPOPs();
}

function renderTagFilterBar() {
  const bar = document.getElementById('tag-filter-bar');
  if (!bar) return;
  const tags = getAllTags();
  const pills = tags.map(t => `<span class="tag-chip ${_activeTagFilter === t ? 'tag-filter-active' : ''}" data-tag-pill="${t}" onclick="setTagFilter('${t}')">#${t}</span>`).join('');
  bar.innerHTML = `
    <span style="font-size:var(--fs-xs);font-weight:700;color:var(--gray-soft);text-transform:uppercase;letter-spacing:.6px">🏷 Tags:</span>
    <span class="tag-chip ${!_activeTagFilter ? 'tag-filter-active' : ''}" data-tag-pill="__all__" id="tag-all" onclick="setTagFilter(null)">Todos</span>
    ${pills}
  `;
}

function tagsEditor(pop) {
  const tags = pop.tags || [];
  return `
    <div class="form-group">
      <label class="form-label">🏷 Tags</label>
      <div class="tags-input-wrap" id="tags-wrap-${pop.code}">
        ${tags.map(t => `<span class="tag-chip">#${t} <span class="tag-x" onclick="removeTagFromPOP('${pop.code}','${t}')">✕</span></span>`).join('')}
        <input class="tags-text-input" id="tags-input-${pop.code}" placeholder="Nova tag (Enter)" onkeydown="addTagFromInput(event,'${pop.code}')">
      </div>
    </div>
  `;
}

function addTagFromInput(e, code) {
  if (e.key !== 'Enter' && e.key !== ',') return;
  e.preventDefault();
  const input = document.getElementById(`tags-input-${code}`);
  const val = input.value.trim().toLowerCase().replace(/[^a-z0-9À-ú\-]/g, '');
  if (!val) return;
  const pop = POPS.find(p => p.code === code);
  if (!pop) return;
  if (!pop.tags) pop.tags = [];
  if (!pop.tags.includes(val)) {
    pop.tags.push(val);
    saveData();
    renderTagFilterBar();
    // re-render the tag wrap
    const wrap = document.getElementById(`tags-wrap-${code}`);
    if (wrap) {
      wrap.innerHTML = pop.tags.map(t => `<span class="tag-chip">#${t} <span class="tag-x" onclick="removeTagFromPOP('${code}','${t}')">✕</span></span>`).join('') +
        `<input class="tags-text-input" id="tags-input-${code}" placeholder="Nova tag (Enter)" onkeydown="addTagFromInput(event,'${code}')">`;
      document.getElementById(`tags-input-${code}`)?.focus();
    }
  } else {
    input.value = '';
  }
}

function removeTagFromPOP(code, tag) {
  const pop = POPS.find(p => p.code === code);
  if (!pop || !pop.tags) return;
  pop.tags = pop.tags.filter(t => t !== tag);
  saveData();
  renderTagFilterBar();
  const wrap = document.getElementById(`tags-wrap-${code}`);
  if (wrap) {
    wrap.innerHTML = pop.tags.map(t => `<span class="tag-chip">#${t} <span class="tag-x" onclick="removeTagFromPOP('${code}','${t}')">✕</span></span>`).join('') +
      `<input class="tags-text-input" id="tags-input-${code}" placeholder="Nova tag (Enter)" onkeydown="addTagFromInput(event,'${code}')">`;
  }
}