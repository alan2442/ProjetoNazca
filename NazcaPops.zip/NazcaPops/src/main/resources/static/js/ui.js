/* ══════════════════════════════════════════
   TOAST NOTIFICATIONS
══════════════════════════════════════════ */
function toast(title, msg, type='success') {
  const icons = {success:'✅', error:'❌', warn:'⚠️', info:'ℹ️'};
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.innerHTML = `
    <span class="toast-icon">${icons[type]||'📢'}</span>
    <div class="toast-body">
      <div class="toast-title">${title}</div>
      ${msg ? `<div class="toast-msg">${msg}</div>` : ''}
    </div>
    <button class="toast-close" onclick="dismissToast(this.parentElement)">✕</button>
  `;
  container.appendChild(el);
  setTimeout(() => dismissToast(el), 4500);
}

function dismissToast(el) {
  if (!el || el._dismissed) return;
  el._dismissed = true;
  el.classList.add('out');
  setTimeout(() => el.remove(), 320);
}

/* ══════════════════════════════════════════
   PRINT / RELATÓRIO
══════════════════════════════════════════ */
function gerarRelatorio() {
  // navigate to POPs page first so it prints
  navigate('pops');
  document.getElementById('print-meta').textContent =
    `Emitido em ${new Date().toLocaleString('pt-BR')} · Total: ${POPS.length} POPs · Usuário: ${currentUser?.name||'Sistema'}`;
  setTimeout(() => window.print(), 400);
}