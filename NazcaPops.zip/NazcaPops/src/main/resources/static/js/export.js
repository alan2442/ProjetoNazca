/* ══════════════════════════════════════════
   EXPORT
══════════════════════════════════════════ */
function exportCSV(){
  const rows=[['Código','Setor','Descrição','Status','Vigência','Treinamento']];
  POPS.forEach(p=>rows.push([p.code,p.sectorName,p.desc,p.docStatus,p.vigencia,p.training]));
  const csv=rows.map(r=>r.map(v=>`"${v}"`).join(',')).join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='NAZCA_POPs_Export.csv';a.click();
}