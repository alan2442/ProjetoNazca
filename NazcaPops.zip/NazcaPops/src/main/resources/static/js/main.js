
/* ══════════════════════════════════════════
   FEATURE 1: LIVE DASHBOARD CLOCK
══════════════════════════════════════════ */
let _clockInterval = null;
function startLiveClock() {
  if (_clockInterval) clearInterval(_clockInterval);
  function tick() {
    const now = new Date();
    const el = document.getElementById('dash-clock');
    const del = document.getElementById('dash-date-str');
    if (!el) return;
    el.textContent = now.toLocaleTimeString('pt-BR');
    del.textContent = now.toLocaleDateString('pt-BR', {weekday:'long',day:'numeric',month:'long',year:'numeric'});

    // Expiry badge counts from real dataRevisao
    const today = now;
    let overdue = 0, soon = 0;
    POPS.forEach(p => {
      const days = calcDaysUntilExpiry(p);
      if (days !== null) {
        if (days < 0) overdue++;
        else if (days <= 90) soon++;
      }
    });
    const ec = document.getElementById('dash-expiry-count');
    if (ec) {
      ec.innerHTML = `
        ${overdue > 0 ? `<span class="expiry-badge danger" onclick="navigate('alertas')">🔴 ${overdue} Vencido${overdue > 1 ? 's' : ''}</span>` : ''}
        ${soon > 0 ? `<span class="expiry-badge warn" onclick="navigate('alertas')">⏰ ${soon} Vencendo</span>` : ''}
        ${(overdue + soon) === 0 ? `<span class="expiry-badge ok">✅ Todos no prazo</span>` : ''}
      `;
    }
    const upd = document.getElementById('dash-updated');
    if (upd) upd.textContent = `Atualizado às ${now.toLocaleTimeString('pt-BR')}`;
  }
  tick();
  _clockInterval = setInterval(tick, 1000);
}



function loadData() {
  try {
    const savedPOPs = localStorage.getItem(LS_KEY_POPS);
    const savedAnexos = localStorage.getItem(LS_KEY_ANEXOS);
    const savedLogs = localStorage.getItem(LS_KEY_LOGS);
    if (savedPOPs) POPS = JSON.parse(savedPOPs);
    if (savedAnexos) {
      ANEXOS = JSON.parse(savedAnexos);
      nextAnexoId = Math.max(...ANEXOS.map(a=>a.id), 0) + 1;
    }
    if (savedLogs) LOGS = JSON.parse(savedLogs);
  } catch(e) { console.warn('LocalStorage load error:', e); }
}




/* ══════════════════════════════════════════
   KEYBOARD SHORTCUTS
══════════════════════════════════════════ */
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){closeModal();closeConfirm();fecharRevisarAnexo();closeCmdPalette();}
  if((e.metaKey||e.ctrlKey)&&e.key==='k'){e.preventDefault();openCmdPalette();}
});