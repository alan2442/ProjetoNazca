package br.com.api.produtos.servico;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.api.produtos.modelo.Funcionario;
import br.com.api.produtos.repositorio.FuncionarioRepositorio;

@Service
public class FuncionarioService {
    

    @Autowired
    private FuncionarioRepositorio fr;


    // listar funcionario
    public Iterable<Funcionario> listarFuncionario() {
        return fr.findAll();
    }


    // cadastrar Funcionario
    public void cadastrarFuncionario(Funcionario funci) {
        if(funci.getNmFuncionario().isEmpty()) {
            throw new RuntimeException("O nome do funcionario é obrigatório");
        }

        fr.save(funci);
    }


    // alterar Funcionario
    public void alterarFuncionario(Funcionario funci) {
        if(funci.getNmFuncionario().isEmpty()) {
            throw new RuntimeException("O nome do funcionario é obrigatório");
        }
        fr.save(funci);
    }


   // Buscar por código 
   public Funcionario buscarPorCodigo(long codigo) {
    return fr.findById(codigo).orElse(null);
   }


   // Deletar Funcionario
   public void deletarFuncionario(long codigo) {
    fr.deleteById(codigo);
   }

}
