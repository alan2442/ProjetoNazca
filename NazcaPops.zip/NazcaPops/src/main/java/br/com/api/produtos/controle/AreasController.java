package br.com.api.produtos.controle;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.api.produtos.modelo.Areas;
import br.com.api.produtos.repositorio.AreasRepository;






@Controller
@ResponseBody
@RequestMapping("/areas")
public class AreasController {
    
    @Autowired
    private AreasRepository repo;


    public List<Areas> listar() {
        return repo.findAll();
    }
}
