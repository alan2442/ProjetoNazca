package br.com.api.produtos.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;


/**
 * Entidade responsável por representar a tabela de instrutores no banco de dados.
 * 
 * Esta classe armazena os dados dos instrutores responsáveis pelos treinamentos
 * ou capacitações relacionadas aos POPs do sistema.
 */
@Entity(name = "Instrutor")

/**
 * Define o nome da tabela no banco de dados.
 */
@Table(name = "Instrutor")

/**
 * Gera automaticamente os métodos GET.
 */
@Getter

/**
 * Gera automaticamente os métodos SET.
 */
@Setter

public class Instrutor {

    /**
     * Chave primária da tabela.
     * 
     * Identificador único do instrutor.
     * O valor é gerado automaticamente pelo banco de dados.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdInstrutor;


    /**
     * Nome do instrutor.
     * 
     * Exemplo:
     * João Silva
     * Maria Oliveira
     */
    private String nmInstrutor;
}