package br.com.api.produtos.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Entidade associativa responsável por relacionar POPs e Áreas.
 * 
 * Esta classe representa uma tabela de ligação (Many-to-Many com entidade própria),
 * permitindo que um POP esteja vinculado a várias áreas e que uma área
 * esteja relacionada a vários POPs.
 */
@Entity(name = "PopsArea")

/**
 * Define o nome da tabela no banco de dados.
 */
@Table(name = "PopsArea")

/**
 * Gera automaticamente um construtor vazio.
 */
@NoArgsConstructor

/**
 * Gera automaticamente um construtor com todos os atributos.
 */
@AllArgsConstructor

/**
 * Gera automaticamente os métodos GET.
 */
@Getter

/**
 * Gera automaticamente os métodos SET.
 */
@Setter

public class PopsArea {

    /**
     * Chave primária da tabela associativa.
     * Identificador único de cada vínculo entre POP e Área.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdPopsArea;


    /**
     * Relacionamento ManyToOne com a entidade Areas.
     * 
     * Indica qual área está vinculada ao POP.
     * A coluna "cdArea" será a chave estrangeira no banco de dados.
     */
    @ManyToOne
    @JoinColumn(name = "cdArea")
    private Areas area;


    /**
     * Relacionamento ManyToOne com a entidade Pops.
     * 
     * Indica qual POP está vinculado à área.
     * A coluna "cdPops" será a chave estrangeira no banco de dados.
     */
    @ManyToOne
    @JoinColumn(name = "cdPops")
    private Pops pops;
}