package br.com.api.produtos.modelo;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity(name = "PopsArea")
@Table (name = "PopsArea")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter



public class PopsArea {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdPopsArea;
    private Long cdArea; // FK
    private Long cdPops; // FK
}
