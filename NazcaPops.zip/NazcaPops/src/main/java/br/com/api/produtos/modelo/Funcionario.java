package br.com.api.produtos.modelo;


import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.*;


@Entity(name = "Funcionario")
@Table (name = "funcionario")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter



public class Funcionario {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdFuncionario;
    private String nmFuncionario;
    private String emailFuncionario;
    private LocalDate dtAdmissao;
    private String nmArea;
    private String nmCargo;
    private String statusFuncionario;
}
