package br.com.api.produtos.modelo;

import java.time.LocalDate;
import java.util.List;



import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import lombok.*;


/**
 * Entidade responsável por representar a tabela de funcionários no banco de dados.
 * 
 * Esta classe armazena os dados básicos dos colaboradores do sistema,
 * como nome, e-mail, data de admissão, área e cargo.
 */
@Entity(name = "Funcionario")

/**
 * Define o nome da tabela no banco de dados.
 */
@Table(name = "funcionario")

/**
 * Gera automaticamente um construtor vazio.
 */
@NoArgsConstructor

/**
 * Gera automaticamente um construtor com todos os atributos.
 */
@AllArgsConstructor

/**
 * Gera automaticamente os métodos GET.
 */
@Getter

/**
 * Gera automaticamente os métodos SET.
 */
@Setter

public class Funcionario {

    /**
     * Chave primária da tabela.
     * 
     * Identificador único do funcionário.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdFuncionario;


    /**
     * Nome completo do funcionário.
     */
    private String nmFuncionario;


    /**
     * E-mail do funcionário.
     */
    private String emailFuncionario;


    /**
     * Data de admissão do funcionário na empresa.
     */
    private LocalDate dtAdmissao;



    /*
     * Relacionamento ManyToOne comentado (versão mais correta da modelagem).
     * 
     * Idealmente, o funcionário deveria estar vinculado
     * diretamente às entidades Areas e Cargos,
     * e não apenas armazenar Strings.
     */
    
    @ManyToOne
    @JoinColumn(name = "cdArea")
    private Areas area;

    @ManyToOne
    @JoinColumn(name = "cdCargo")
    private Cargos cargo;
    


    /**
     * Status atual do funcionário no sistema.
     * Exemplo:
     * Ativo, Inativo, Afastado, etc.
     */
    private String statusFuncionario;


    
    


    /**
     * Relacionamento entre Funcionario e Treinamento.
     * 
     * Um funcionário pode participar de vários treinamentos POP.
     * 
     * mappedBy = "funcionario"
     * indica que a entidade Treinamento é responsável
     * pelo controle do relacionamento.
     */
    @OneToMany(mappedBy = "funcionario")

    /**
     * Evita loop infinito na conversão para JSON na API.
     */
    @JsonIgnore

    /**
     * Lista de treinamentos associados ao funcionário.
     */
    private List<Treinamento> treinamentos;
}