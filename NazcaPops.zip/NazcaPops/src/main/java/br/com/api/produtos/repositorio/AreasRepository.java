package br.com.api.produtos.repositorio;

import org.springframework.stereotype.Repository;

import br.com.api.produtos.modelo.Areas;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface AreasRepository extends JpaRepository<Areas, Long> {

    
}
