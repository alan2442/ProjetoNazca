package br.com.api.produtos.repositorio;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.api.produtos.modelo.Funcionario;


@Repository
public interface FuncionarioRepositorio extends JpaRepository<Funcionario, Long> {
    
    
} 