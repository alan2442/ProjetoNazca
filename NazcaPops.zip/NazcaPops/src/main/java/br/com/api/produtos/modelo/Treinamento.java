package br.com.api.produtos.modelo;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Entidade responsável por representar a tabela de Treinamentos no banco de dados.
 * 
 * Esta tabela registra a participação de funcionários em treinamentos relacionados
 * aos POPs (Procedimentos Operacionais Padrão).
 */
@Entity(name = "Treinamento")

/**
 * Define o nome da tabela no banco de dados.
 */
@Table(name = "Treinamento")

/**
 * Gera automaticamente um construtor vazio.
 */
@NoArgsConstructor

/**
 * Gera automaticamente um construtor com todos os atributos.
 */
@AllArgsConstructor

/**
 * Gera automaticamente os métodos GET.
 */
@Getter

/**
 * Gera automaticamente os métodos SET.
 */
@Setter




public class Treinamento {

    /**
     * Chave primária da tabela.
     * Identificador único de cada registro de treinamento.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdTreinamento;


    /**
     * Relacionamento ManyToOne com a entidade Funcionario.
     * 
     * Indica qual funcionário participou do treinamento.
     * A coluna "cdFuncionario" será a chave estrangeira no banco de dados.
     */
    @ManyToOne
    @JoinColumn(name = "cdFuncionario")
    private Funcionario funcionario;


    /**
     * Relacionamento ManyToOne com a entidade Pops.
     * 
     * Indica qual POP foi utilizado no treinamento.
     * A coluna "cdPops" será a chave estrangeira no banco de dados.
     */
    @ManyToOne
    @JoinColumn(name = "cdPops")
    private Pops pops;
}