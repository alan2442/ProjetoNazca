package br.com.api.produtos.modelo;


import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity(name = "Treinamento")
@Table (name = "Treinamento")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter



public class Treinamento {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdTreinamento;
    private Long cdFuncionario; //FK
    private Long cdPops; //FK
}
