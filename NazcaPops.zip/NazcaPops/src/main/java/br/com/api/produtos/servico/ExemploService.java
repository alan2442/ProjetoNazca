package br.com.api.produtos.servico;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.api.produtos.modelo.ProdutoModelo;
import br.com.api.produtos.repositorio.ProdutoRepositorio;

@Service
public class ProdutoServico {

    @Autowired
    private ProdutoRepositorio pr;

    // listar produtos
    public Iterable<ProdutoModelo> listar() {
        return pr.findAll();
    }

    // cadastrar produto
    public void cadastrar(ProdutoModelo pm) {

        if(pm.getNome().isEmpty()) {
            throw new RuntimeException("O nome do produto é obrigatório");
        }

        if(pm.getMarca().isEmpty()) {
            throw new RuntimeException("O nome da marca é obrigatório");
        }

        pr.save(pm);
    }

    // alterar produto
    public void alterar(ProdutoModelo pm) {

        if(pm.getNome().isEmpty()) {
            throw new RuntimeException("O nome do produto é obrigatório");
        }

        if(pm.getMarca().isEmpty()) {
            throw new RuntimeException("O nome da marca é obrigatório");
        }

        pr.save(pm);
    }

    // buscar por código
    public ProdutoModelo buscarPorCodigo(long codigo) {

        return pr.findById(codigo).orElse(null);
    }

    // remover produto
    public void remover(long codigo) {

        pr.deleteById(codigo);
    }
}