package br.com.api.produtos.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Entidade associativa responsável por relacionar POPs e Anexos.
 * 
 * Esta classe representa uma tabela de ligação (Many-to-Many com entidade própria),
 * permitindo que um POP tenha vários anexos e que um anexo possa estar vinculado
 * a vários POPs.
 */
@Entity(name = "PopsAnexo")

/**
 * Define o nome da tabela no banco de dados.
 */
@Table(name = "PopsAnexo")

/**
 * Gera automaticamente um construtor vazio.
 */
@NoArgsConstructor

/**
 * Gera automaticamente um construtor com todos os atributos.
 */
@AllArgsConstructor

/**
 * Gera automaticamente os métodos GET.
 */
@Getter

/**
 * Gera automaticamente os métodos SET.
 */
@Setter

public class PopsAnexo {

    /**
     * Chave primária da tabela associativa.
     * Identificador único de cada vínculo entre POP e Anexo.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdPopsAnexo;


    /**
     * Relacionamento ManyToOne com a entidade Anexos.
     * 
     * Indica qual anexo está vinculado ao POP.
     * A coluna "cdAnexos" será a chave estrangeira no banco.
     */
    @ManyToOne
    @JoinColumn(name = "cdAnexos")
    private Anexos anexos;


    /**
     * Relacionamento ManyToOne com a entidade Pops.
     * 
     * Indica qual POP está vinculado ao anexo.
     * A coluna "cdPops" será a chave estrangeira no banco.
     */
    @ManyToOne
    @JoinColumn(name = "cdPops")
    private Pops pops;
}