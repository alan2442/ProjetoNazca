package br.com.api.produtos.modelo;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity(name = "PopsAnexo")
@Table (name = "PopsAnexo")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter



public class PopsAnexo {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdPopsAnexo;
    private Long cdAnexos; // FK
    private Long cdPops; // FK
}
