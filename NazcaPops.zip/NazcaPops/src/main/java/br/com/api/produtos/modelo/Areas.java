package br.com.api.produtos.modelo;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;


@Entity(name = "Cargos")
@Table (name = "Cargos")
@Getter
@Setter



public class Cargos {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdCargo;
    private String nmFuncionario;
    private String emailFuncionario;
    // private Date dtAdmissao;
    private Long cdCargo; // FK
}
