package br.com.api.produtos.modelo;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Entidade responsável por representar a tabela de áreas no banco de dados.
 * 
 * Esta classe armazena as áreas/setores cadastrados no sistema,
 * como por exemplo:
 * RH, Qualidade, Produção, TI, etc.
 */
@Entity(name = "Areas")

/**
 * Define o nome da tabela no banco de dados.
 */
@Table(name = "Areas")

/**
 * Gera automaticamente um construtor vazio.
 */
@NoArgsConstructor

/**
 * Gera automaticamente um construtor com todos os atributos.
 */
@AllArgsConstructor

/**
 * Gera automaticamente os métodos GET.
 */
@Getter

/**
 * Gera automaticamente os métodos SET.
 */
@Setter

public class Areas {

    /**
     * Chave primária da tabela.
     * 
     * O valor é gerado automaticamente pelo banco.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdArea;


    /**
     * Nome da área.
     * 
     * Exemplos:
     * - Recursos Humanos
     * - Produção
     * - Qualidade
     * - Tecnologia da Informação
     */
    private String nmArea;


    /**
     * Relacionamento entre Areas e PopsArea.
     * 
     * Uma área pode estar vinculada a vários POPs.
     * 
     * mappedBy = "area"
     * indica que a entidade PopsArea é responsável
     * pelo gerenciamento do relacionamento.
     */
    @OneToMany(mappedBy = "area")
    private List<PopsArea> popsAreas;
}