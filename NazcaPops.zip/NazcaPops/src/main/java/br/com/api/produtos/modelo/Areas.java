package br.com.api.produtos.modelo;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity(name = "Areas")
@Table (name = "Areas")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter



public class Areas {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdArea;
    private String nmArea;
}
