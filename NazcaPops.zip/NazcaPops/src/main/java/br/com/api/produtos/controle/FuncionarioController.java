package br.com.api.produtos.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import br.com.api.produtos.modelo.Funcionario;
import br.com.api.produtos.servico.FuncionarioService;
import ch.qos.logback.core.model.Model;

@Controller
public class FuncionarioController {
    
    

    // Página principal
    @Autowired
    private FuncionarioService fs;
    
    // Cadastrar Funcionario
    @PostMapping("/cadastrarFuncionario")
    public String cadastrar(@ModelAttribute Funcionario funci) {
        fs.cadastrarFuncionario(funci);

        return "redirect:/";
    }


    
}
