package br.com.api.produtos.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.api.produtos.modelo.Funcionario;
import br.com.api.produtos.servico.FuncionarioService;

@Controller
public class FuncionarioController {

    @Autowired
    private FuncionarioService fs;



    // Rota Index
    @GetMapping("/")
    public String inicio() {

        return "index";
    }

    // cadastrar
    @PostMapping("/cadastrarFuncionario")
    @ResponseBody
    public String cadastrar(@RequestBody Funcionario funci) {

        fs.cadastrarFuncionario(funci);

        return "Funcionário cadastrado";
    }

    // alterar
    @PostMapping("/alterarFuncionario")
    @ResponseBody
    public String alterar(@RequestBody Funcionario funci) {

        fs.alterarFuncionario(funci);

        return "Funcionário alterado";
    }

    // deletar
    @GetMapping("/deletarFuncionario/{codigo}")
    public String remover(@PathVariable long codigo) {

        fs.deletarFuncionario(codigo);

        return "redirect:/";
    }
}