package br.com.api.produtos.controle;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.api.produtos.modelo.Cargos;
import br.com.api.produtos.repositorio.CargosRepository;




@Controller
@ResponseBody
@RequestMapping("/cargos")
public class CargoController {
    
    @Autowired
    private CargosRepository repo;



    @GetMapping
    public List<Cargos> listar() {
        return repo.findAll();
    }

    @GetMapping("/por-area/{id}")
    public List<Cargos> porArea(@PathVariable Long id) {
        return repo.findByAreaCdArea(id);
    }
}
