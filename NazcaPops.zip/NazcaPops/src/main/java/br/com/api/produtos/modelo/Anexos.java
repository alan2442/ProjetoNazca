package br.com.api.produtos.modelo;


import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity(name = "Anexos")
@Table (name = "Anexos")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter



public class Anexos {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdAnexos;
    private String nmAnexo;
    private String nmrAnexo;
    private String popVinculado;
    private LocalDate dtCriacao;
    private String arquivo; // guarda Arquivo word e null
    private String descAnexo;
   
}
