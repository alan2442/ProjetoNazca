package br.com.api.produtos.modelo;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Entidade responsável por representar a tabela de anexos no banco de dados.
 * 
 * Esta classe armazena informações relacionadas aos documentos/anexos
 * vinculados aos POPs do sistema.
 */
@Entity(name = "Anexos")

/**
 * Define o nome da tabela no banco.
 */
@Table(name = "Anexos")

/**
 * Gera automaticamente um construtor vazio.
 */
@NoArgsConstructor

/**
 * Gera automaticamente um construtor com todos os atributos.
 */
@AllArgsConstructor

/**
 * Gera automaticamente os métodos GET.
 */
@Getter

/**
 * Gera automaticamente os métodos SET.
 */
@Setter

public class Anexos {

    /**
     * Chave primária da tabela.
     * 
     * O valor é gerado automaticamente pelo banco de dados.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdAnexos;


    /**
     * Nome do anexo.
     * 
     * Exemplo:
     * Manual de Segurança
     */
    private String nmAnexo;


    /**
     * Número ou código identificador do anexo.
     * 
     * Exemplo:
     * ANX-001
     */
    private String nmrAnexo;


    /**
     * Nome do POP vinculado ao anexo.
     * 
     * OBS:
     * Este campo pode se tornar redundante,
     * pois já existe relacionamento através
     * da entidade associativa PopsAnexo.
     */
    private String popVinculado;


    /**
     * Data de criação do anexo.
     */
    private LocalDate dtCriacao;


    /**
     * Nome ou caminho do arquivo armazenado.
     * 
     * Exemplo:
     * manual.docx
     * procedimento.pdf
     * 
     * Pode ser nulo caso o anexo ainda não possua arquivo.
     */
    private String arquivo;


    /**
     * Descrição detalhada do anexo.
     */
    private String descAnexo;


    /**
     * Relacionamento entre Anexos e PopsAnexo.
     * 
     * Um anexo pode estar associado a vários POPs.
     * 
     * mappedBy = "anexos"
     * indica que a entidade PopsAnexo é responsável
     * pelo gerenciamento do relacionamento.
     */
    @OneToMany(mappedBy = "anexos")


    /**
     * Impede problemas de serialização JSON e loops infinitos
     * ao retornar dados pela API.
     */
    @JsonIgnore

    /**
     * Lista de vínculos entre anexos e POPs.
     */
    private List<PopsAnexo> popsAnexos;
}