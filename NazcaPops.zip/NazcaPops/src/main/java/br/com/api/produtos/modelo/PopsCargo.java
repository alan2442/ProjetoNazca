package br.com.api.produtos.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Entidade associativa responsável por relacionar POPs e Cargos.
 * 
 * Esta classe representa uma tabela de ligação (Many-to-Many com entidade própria),
 * permitindo que um POP esteja vinculado a vários cargos e que um cargo
 * esteja relacionado a vários POPs.
 */
@Entity(name = "PopsCargo")

/**
 * Define o nome da tabela no banco de dados.
 */
@Table(name = "PopsCargo")

/**
 * Gera automaticamente um construtor vazio.
 */
@NoArgsConstructor

/**
 * Gera automaticamente um construtor com todos os atributos.
 */
@AllArgsConstructor

/**
 * Gera automaticamente os métodos GET.
 */
@Getter

/**
 * Gera automaticamente os métodos SET.
 */
@Setter

public class PopsCargo {

    /**
     * Chave primária da tabela associativa.
     * Identificador único de cada vínculo entre POP e Cargo.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdPopsCargo;


    /**
     * Relacionamento ManyToOne com a entidade Cargos.
     * 
     * Indica qual cargo está vinculado ao POP.
     * A coluna "cdCargo" será a chave estrangeira no banco de dados.
     */
    @ManyToOne
    @JoinColumn(name = "cdCargo")
    private Cargos cargo;


    /**
     * Relacionamento ManyToOne com a entidade Pops.
     * 
     * Indica qual POP está vinculado ao cargo.
     * A coluna "cdPops" será a chave estrangeira no banco de dados.
     */
    @ManyToOne
    @JoinColumn(name = "cdPops")
    private Pops pops;
}