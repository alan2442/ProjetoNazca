package br.com.api.produtos.modelo;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity(name = "PopsCargo")
@Table (name = "PopsCargo")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter



public class PopsCargo {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdPopsCargo;
    private Long cdCargo; // FK
    private Long cdPops; // FK
}
