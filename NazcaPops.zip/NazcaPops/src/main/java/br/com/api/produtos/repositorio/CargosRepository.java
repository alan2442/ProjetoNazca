package br.com.api.produtos.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.api.produtos.modelo.Cargos;


@Repository
public interface CargosRepository extends JpaRepository<Cargos, Long> {
    
    List<Cargos> findByAreaCdArea(Long cdArea);

}
