package br.com.api.produtos.modelo;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Entidade responsável por representar a tabela de cargos no banco de dados.
 * 
 * Esta classe armazena os cargos existentes no sistema,
 * como por exemplo:
 * Analista, Supervisor, Operador, Gerente, etc.
 */
@Entity(name = "Cargos")

/**
 * Define o nome da tabela no banco de dados.
 */
@Table(name = "Cargos")

/**
 * Gera automaticamente um construtor vazio.
 */
@NoArgsConstructor

/**
 * Gera automaticamente um construtor com todos os atributos.
 */
@AllArgsConstructor

/**
 * Gera automaticamente os métodos GET.
 */
@Getter

/**
 * Gera automaticamente os métodos SET.
 */
@Setter

public class Cargos {

    /**
     * Chave primária da tabela.
     * 
     * O valor é gerado automaticamente pelo banco de dados.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdCargo;


    /**
     * Nome do cargo.
     * 
     * Exemplos:
     * - Analista
     * - Supervisor
     * - Coordenador
     * - Operador
     */
    private String nmCargo;


    /*
     * Antiga abordagem utilizando apenas o ID manualmente.
     * 
     * Atualmente o relacionamento é realizado corretamente
     * através da entidade Areas usando JPA/Hibernate.
     */
    /*
    private Long cdPops;
    */


    /**
     * Relacionamento ManyToOne entre Cargo e Área.
     * 
     * Muitos cargos podem pertencer a uma única área.
     * 
     * Exemplo:
     * Área: Produção
     * Cargos:
     * - Operador
     * - Supervisor
     * - Líder
     * 
     * A anotação @JoinColumn define o nome da chave estrangeira
     * criada na tabela "Cargos".
     */
    @ManyToOne
    @JoinColumn(name = "cdArea")
    private Areas area;


    /**
     * Relacionamento entre Cargos e PopsCargo.
     * 
     * Um cargo pode estar associado a vários POPs
     * através da tabela associativa PopsCargo.
     * 
     * mappedBy = "cargo"
     * indica que a entidade PopsCargo é responsável
     * pelo gerenciamento do relacionamento.
     */
    @OneToMany(mappedBy = "cargo")
    private List<PopsCargo> popsCargos;
}