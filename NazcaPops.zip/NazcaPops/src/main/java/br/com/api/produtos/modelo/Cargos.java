package br.com.api.produtos.modelo;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity(name = "Cargos")
@Table (name = "Cargos")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter



public class Cargos {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdCargo;
    private String nmCargo;
    /* 
    private Long cdPops; // FK
    private Long cdArea; // FK
    */
}
