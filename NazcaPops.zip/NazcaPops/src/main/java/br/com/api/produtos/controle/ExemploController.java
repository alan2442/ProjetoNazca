package br.com.api.produtos.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import br.com.api.produtos.modelo.ProdutoModelo;
import br.com.api.produtos.servico.ProdutoServico;

@Controller
public class ProdutoControle {

    @Autowired
    private ProdutoServico ps;

    // página principal
    @GetMapping("/")
    public String inicio(Model model) {

        model.addAttribute("produtos", ps.listar());

        return "index";
    }

    // abrir formulário de cadastro
    @GetMapping("/cadastrar")
    public String cadastrarFormulario(Model model) {

        model.addAttribute("produto", new ProdutoModelo());

        return "cadastrar";
    }

    // cadastrar produto
    @PostMapping("/cadastrar")
    public String cadastrar(@ModelAttribute ProdutoModelo pm) {

        ps.cadastrar(pm);

        return "redirect:/";
    }

    // abrir tela de edição
    @GetMapping("/editar/{codigo}")
    public String editar(@PathVariable long codigo, Model model) {

        ProdutoModelo produto = ps.buscarPorCodigo(codigo);

        model.addAttribute("produto", produto);

        return "editar";
    }

    // alterar produto
    @PostMapping("/alterar")
    public String alterar(@ModelAttribute ProdutoModelo pm) {

        ps.alterar(pm);

        return "redirect:/";
    }

    // remover produto
    @GetMapping("/remover/{codigo}")
    public String remover(@PathVariable long codigo) {

        ps.remover(codigo);

        return "redirect:/";
    }
}