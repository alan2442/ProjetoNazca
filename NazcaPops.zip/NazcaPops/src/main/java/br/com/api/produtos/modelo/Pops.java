package br.com.api.produtos.modelo;


import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity(name = "Pops")
@Table (name = "Pops")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter



public class Pops {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdPops;
    private String nmPops;
    private String setorPops;
    private String areaPops;
    private String cargoPops;
    private String statusPops;
    private String descPops;
    private LocalDate dtCriacao;
    private LocalDate dtVencimento;
    private String PossuiAnexo; // null
   
}
