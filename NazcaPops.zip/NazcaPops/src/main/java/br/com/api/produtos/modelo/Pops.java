package br.com.api.produtos.modelo;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Entidade responsável por representar a tabela de POPs (Procedimentos Operacionais Padrão)
 * no banco de dados.
 * 
 * Um POP é um documento que descreve um procedimento que deve ser seguido dentro da empresa,
 * garantindo padronização e qualidade dos processos.
 */
@Entity(name = "Pops")

/**
 * Define o nome da tabela no banco de dados.
 */
@Table(name = "Pops")

/**
 * Gera automaticamente um construtor vazio.
 */
@NoArgsConstructor

/**
 * Gera automaticamente um construtor com todos os atributos.
 */
@AllArgsConstructor

/**
 * Gera automaticamente os métodos GET.
 */
@Getter

/**
 * Gera automaticamente os métodos SET.
 */
@Setter

public class Pops {

    /**
     * Chave primária da tabela.
     * Identificador único do POP.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdPops;


    /**
     * Nome do POP.
     * Exemplo: "Procedimento de Segurança"
     */
    private String nmPops;


    /**
     * Setor responsável pelo POP.
     */
    private String setorPops;


    /**
     * Área vinculada ao POP (descrição em texto).
     * OBS: Idealmente deveria ser relacionamento com a entidade Areas.
     */
    private String areaPops;


    /**
     * Cargo relacionado ao POP (descrição em texto).
     * OBS: Idealmente deveria ser relacionamento com a entidade Cargos.
     */
    private String cargoPops;


    /**
     * Status do POP no sistema.
     * Exemplo: Ativo, Inativo, Em revisão.
     */
    private String statusPops;


    /**
     * Descrição detalhada do POP.
     */
    private String descPops;


    /**
     * Data de criação do POP.
     */
    private LocalDate dtCriacao;


    /**
     * Data de vencimento ou revisão do POP.
     */
    private LocalDate dtVencimento;


    /**
     * Indica se o POP possui anexo associado.
     * OBS: poderia ser substituído por relacionamento com Anexos.
     */
    private String PossuiAnexo;


    /**
     * Relacionamento entre POPs e Áreas através da entidade associativa PopsArea.
     */
    @OneToMany(mappedBy = "pops")
    @JsonIgnore
    private List<PopsArea> popsAreas;


    /**
     * Relacionamento entre POPs e Cargos através da entidade associativa PopsCargo.
     */
    @OneToMany(mappedBy = "pops")
    @JsonIgnore
    private List<PopsCargo> popsCargos;


    /**
     * Relacionamento entre POPs e Treinamentos.
     * Um POP pode estar presente em vários treinamentos.
     */
    @OneToMany(mappedBy = "pops")
    @JsonIgnore
    private List<Treinamento> treinamentos;


    /**
     * Relacionamento entre POPs e Anexos através da entidade associativa PopsAnexo.
     */
    @OneToMany(mappedBy = "pops")
    @JsonIgnore
    private List<PopsAnexo> popsAnexos;
}